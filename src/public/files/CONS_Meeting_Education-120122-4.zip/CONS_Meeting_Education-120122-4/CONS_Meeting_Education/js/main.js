"use strict";

const hostList = [
	"http://localhost:3000",
	"https://cons-meeting-education.herokuapp.com",
];
const hostIndex = 1;
const host = hostList[hostIndex];

const $ = (selector, bindObj = document) => {
	return bindObj.querySelector(selector);
};
const $$ = (selector, bindObj = document) => {
	return bindObj.querySelectorAll(selector);
};
const pagesName = ["startPage", "joinPage", "classPage"];

initFontAwsome();

function getLink(filePath) {
	return chrome.runtime.getURL(filePath);
}

function initFontAwsome() {
	const linkElm = document.createElement("link");

	linkElm.rel = "stylesheet";
	linkElm.href =
		"https://pro.fontawesome.com/releases/v5.10.0/css/all.css";

	document.head.appendChild(linkElm);
}

Array.prototype.sortObject = function (fieldName, sortType) {
	if (sortType === 0) {
		this.sort((a, b) => a[fieldName] - b[fieldName]);
	} else {
		this.sort((a, b) => b[fieldName] - a[fieldName]);
	}

	return this;
};

class UserId {
	storageKey = "googleMeetExtension___UserId";

	initial() {
		const userId = this.getUserId();

		if (!userId) {
			const getUserURL = `${host}/manager/create`;

			fetch(getUserURL)
				.then((res) => res.json())
				.then((data) => {
					const userId = data._id;

					this.setUserId(userId);
				});
		}

		if (userId) {
			const resetLastOnlineURL = `${host}/manager/join/${userId}`;
			const resetLastOnlineOption = {
				method: "PATCH",
				headers: {
					"Content-Type": "application/json",
				},
			};

			fetch(resetLastOnlineURL, resetLastOnlineOption)
				.then((res) => res.json())
				.then((data) => console.log(data))
				.catch((err) => console.log(err));
		}
	}

	getUserId() {
		const userId = JSON.parse(localStorage.getItem(this.storageKey));

		return userId;
	}

	setUserId(newUserId) {
		const newUserIdJson = JSON.stringify(newUserId);

		localStorage.setItem(this.storageKey, newUserIdJson);
	}
}
var userIdObj = new UserId();
userIdObj.initial();

// General Methods
class GeneralMethods {
	sleep(time) {
		return new Promise((resolve) => {
			setTimeout(resolve, time);
		});
	}

	secondToMinute(second) {
		const minutes = Number.parseInt(second / 60);
		const seconds = second % 60;

		return `${minutes}p${seconds}s`;
	}

	convertTimeSecond(second) {
		let hoursLearning = Math.floor(second / 3600);
		let minutesLearning = Math.floor((second % 3600) / 60);
		let secondsLearning = second % 60;

		hoursLearning =
			`${hoursLearning}`.length < 2
				? `0${hoursLearning}`
				: `${hoursLearning}`;
		minutesLearning =
			`${minutesLearning}`.length < 2
				? `0${minutesLearning}`
				: `${minutesLearning}`;
		secondsLearning =
			`${secondsLearning}`.length < 2
				? `0${secondsLearning}`
				: `${secondsLearning}`;

		return {
			hours: hoursLearning,
			minutes: minutesLearning,
			seconds: secondsLearning,
		};
	}

	getLocalTime(type = 1) {
		const timeObj = this.getCurrentTime();

		if (type === 1) {
			return `${timeObj.hours}:${timeObj.minutes}:${timeObj.seconds}: - ${timeObj.weekDays} ${timeObj.dates}/${timeObj.months}/${timeObj.years}`;
		} else {
			return `${timeObj.hours}h${timeObj.minutes}m${timeObj.seconds}s - ${timeObj.weekDays} ${timeObj.dates}/${timeObj.months}/${timeObj.years}`;
		}
	}

	getCurrentTime() {
		const localTime = new Date(Date.now());
		let localSecond = localTime.getSeconds();
		let localMinutes = localTime.getMinutes();
		let localHours = localTime.getHours();
		let localDate = localTime.getDate();
		let localMonth = localTime.getMonth() + 1;
		let localYear = localTime.getFullYear();
		let localDayOfWeek;

		if (localTime.getDay() === 0) {
			localDayOfWeek = 8;
		} else {
			localDayOfWeek = localTime.getDay() + 1;
		}

		return {
			seconds:
				`${localSecond}`.length < 2
					? `0${localSecond}`
					: `${localSecond}`,
			minutes:
				`${localMinutes}`.length < 2
					? `0${localMinutes}`
					: `${localMinutes}`,
			hours:
				`${localHours}`.length < 2
					? `0${localHours}`
					: `${localHours}`,
			dates:
				`${localDate}`.length < 2 ? `0${localDate}` : `${localDate}`,
			months:
				`${localMonth}`.length < 2
					? `0${localMonth}`
					: `${localMonth}`,
			years:
				`${localYear}`.length < 2 ? `0${localYear}` : `${localYear}`,
			weekDays: `0${localDayOfWeek}`,
		};
	}

	getTimeStr(hasTime, hasWeekDays, hasDates, timeObj) {
		if (timeObj) {
			return getString(timeObj);
		} else {
			return getString(this.getCurrentTime());
		}

		function getString(timeInfoObj) {
			const timeStr = hasTime
				? `${timeInfoObj.hours}:${timeInfoObj.minutes}:${timeInfoObj.seconds} `
				: "";
			const weekDaysStr = hasWeekDays
				? `- ${
						+timeObj.weekDays === 8 ? "CN" : `T${+timeObj.weekDays}`
				  }`
				: "";
			const datesStr = hasDates
				? hasWeekDays
					? ` ${timeInfoObj.dates}/${timeInfoObj.months}/${timeInfoObj.years}`
					: `- ${timeInfoObj.dates}/${timeInfoObj.months}/${timeInfoObj.years}`
				: "";

			return timeStr + weekDaysStr + datesStr;
		}
	}

	async domHandleWithCondition(
		domSelector = "",
		stopCondition = function () {},
		duration = 100,
		callbackHandle = async function () {}
	) {
		return new Promise((resolve) => {
			let interval = setInterval(async () => {
				const stopConditionResult = stopCondition();
				if (stopConditionResult) {
					clearInterval(interval);
					resolve();
					return;
				}

				const domElement = $(domSelector);
				if (domElement) {
					callbackHandle(domElement);
				}
			}, duration);
		});
	}

	async getDom(classNameElm, multiple = false, duration = 50) {
		return new Promise((resolve) => {
			const interval = setInterval(() => {
				if (multiple ? $$(classNameElm) : $(classNameElm)) {
					resolve(multiple ? $$(classNameElm) : $(classNameElm));
					clearInterval(interval);
				}
			}, duration);
		});
	}

	triggerEvent(element, eventName) {
		var event = document.createEvent("HTMLEvents");
		event.initEvent(eventName, false, true);
		element.dispatchEvent(event);
	}

	validateEmail(email) {
		var re =
			/^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
		return re.test(email.trim());
	}
}
var generalMethods = new GeneralMethods();

class Settings {
	defaultSettingsInfo = {
		class: "12A12",
		autoTurnOffMedia: true,
		autoAttendance: false,
		autoAccept: false,
		blockAccessInvalid: false,
		timingExistPercent: 80,
	};

	initial() {
		this.getSettings();
	}

	getSettings() {
		const settingsJson = localStorage.getItem(
			"googleMeetExtension___Settings"
		);

		if (settingsJson) {
			const settingsJs = JSON.parse(settingsJson);
			return settingsJs;
		}

		localStorage.setItem(
			"googleMeetExtension___Settings",
			JSON.stringify(this.defaultSettingsInfo)
		);

		return this.defaultSettingsInfo;
	}

	setSettings(newSettings) {
		const currentSettings = this.getSettings();

		localStorage.setItem(
			"googleMeetExtension___Settings",
			JSON.stringify({
				...currentSettings,
				...newSettings,
			})
		);

		classPageObj.settingsBox.settingsBoxFeaturesResetStyle();
	}
}
var settingsObj = new Settings();
settingsObj.initial();

class Members {
	defaultClassListInfo = [
		{
			classInfoName: "default",
			data: [
				{
					index: 1,
					name: "Nhấn để chỉnh sửa tên học sinh",
					meetName: "Nhấn để sửa tên Meet",
					gmail: "test@gmail.com",
					group: 1,
				},
			],
		},
		{
			classInfoName: "12A12",
			data: [
				{
					index: 8,
					name: "Trần Văn Còn",
					group: 1,
					meetName: "08.Còn-12A12",
					gmail: "tranvanconkg@gmail.com",
				},
			],
		},
	];

	getCurrentClassInfoName() {
		return (
			JSON.parse(
				localStorage.getItem(
					"googleMeetExtension___Members__CurrentClass"
				)
			) || undefined
		);
	}

	setCurrentClass(newClassInfoName) {
		localStorage.setItem(
			"googleMeetExtension___Members__CurrentClass",
			JSON.stringify(newClassInfoName)
		);
	}

	initial() {
		const membersInfo = this.getAllClassInfo();

		if (!membersInfo.length) {
			const defaultMembersInfoJSON = JSON.stringify(
				this.defaultClassListInfo
			);

			localStorage.setItem(
				"googleMeetExtension___Members",
				defaultMembersInfoJSON
			);
		}

		if (!this.getCurrentClassInfoName())
			localStorage.setItem(
				"googleMeetExtension___Members__CurrentClass",
				JSON.stringify("default")
			);
	}

	getAllClassInfo() {
		return (
			JSON.parse(
				localStorage.getItem("googleMeetExtension___Members")
			) || []
		);
	}

	getAllClassName() {
		const classListInfo = this.getAllClassInfo();

		return classListInfo.map((classInfo) => classInfo.classInfoName);
	}

	getClass(classInfoName) {
		if (!classInfoName) classInfoName = this.getCurrentClassInfoName();

		const classListInfo = this.getAllClassInfo();

		return classListInfo.find(
			(classInfo) => classInfo.classInfoName === classInfoName
		);
	}

	setClass(classInfoName, newClassList, reRender = false) {
		let wasReplace = false;
		let newAllClassInfo = this.getAllClassInfo().map((classInfo) => {
			if (classInfo.classInfoName === classInfoName) {
				wasReplace = true;
				return {
					classInfoName,
					data: newClassList,
				};
			} else {
				return classInfo;
			}
		});

		if (!wasReplace) {
			newAllClassInfo.push(newClassList);
		}

		localStorage.setItem(
			"googleMeetExtension___Members",
			JSON.stringify(newAllClassInfo)
		);

		if (reRender) classPageObj.settingsBox.renderStudentList();
	}

	setAllClass(newAllClassInfo, reRender = false) {
		const hasCurrentClassName = newAllClassInfo
			.map((classInfo) => classInfo.classInfoName)
			.some(
				(classInfoName) =>
					classInfoName === this.getCurrentClassInfoName()
			);

		if (!hasCurrentClassName) this.setCurrentClass("default");

		localStorage.setItem(
			"googleMeetExtension___Members",
			JSON.stringify(newAllClassInfo)
		);

		if (reRender) {
			classPageObj.settingsBox.renderStudentList();
		}
	}
}
var membersObj = new Members();
membersObj.initial();

if (localStorage.getItem("googleMeetExtension___GroupStorage") === null) {
	localStorage.setItem(
		"googleMeetExtension___GroupStorage",
		JSON.stringify([])
	);
}

class Attendance {
	startAttendanceAt = undefined;
	endAttendanceAt = undefined;
	totalTimeLearning = undefined;
	attendanceData = undefined;
	domVariables = {
		attendanceListWrapper: () =>
			$(
				".settings-box__wrapper .tab-list__item.statistical .slide-3__student-wrapper"
			),
		disabledStatusElm: () =>
			$(
				".settings-box__wrapper .tab-list__item.statistical .statistical__state-message"
			),
		disabledStatusContentElm: () =>
			$(
				".settings-box__wrapper .tab-list__item.statistical .statistical__state-message span"
			),
		currentClassElm: () =>
			$(
				".settings-box__wrapper .tab-list__item.statistical .slide-1__class-info-name .class-info-name__class-name"
			),
		totalTimeLearningElm: () =>
			$(
				".settings-box__wrapper .tab-list__item.statistical .slide-1__time-learning .time-learning__time"
			),
		studentExistListElm: () =>
			$(
				".settings-box__wrapper .tab-list__item.statistical .slide-1__student-exist-count .student-exist-count__count"
			),
		notExistStudentBoxELm: () =>
			$(
				".settings-box__wrapper .tab-list__item.statistical .slide-2__not-exist-student .not-exist-student__box"
			),
		notExistStudentBoxLabelELm: () =>
			$(
				".settings-box__wrapper .tab-list__item.statistical .slide-2__not-exist-student .not-exist-student__caption"
			),
		turnOnStateMessageElm: () =>
			$(
				".taskbar__left .left__attendance-state .attendance-state__attendance-message .attendance-message__on-state p"
			),
	};

	initial() {
		this.handleChangeClass(membersObj.getCurrentClassInfoName());
	}

	handleChangeClass(classInfoName) {
		const allGroupInfo = JSON.parse(
			localStorage.getItem("googleMeetExtension___GroupStorage")
		);

		this.attendanceData = membersObj
			.getClass(classInfoName)
			.data.map((member) => {
				const allworkingGroupTimes = allGroupInfo
					.filter((groupInfo) =>
						groupInfo.membersIndex.includes(member.index)
					)
					.map((groupInfo) => ({
						eventId: groupInfo.eventId,
						startAt: groupInfo.startAt,
						endAt: groupInfo.endAt,
					}));

				return {
					index: member.index,
					name: member.name,
					meetName: member.meetName,
					timeLearning: 0,
					percentLearning: 0,
					isOnline: false,
					joinAndExitTimers: [],
					chats: [],
					micStatus: false,
					micCount: 0,
					micDuration: 0,
					notExistStatus: 0 /* 0 -> exit, 1 -> not accept, 2 -> accept */,
					acceptNotExist: false,

					// Group working
					isWorkingGroup: false,
					workingGroupTimes: allworkingGroupTimes,
				};
			});
	}

	turnOn() {
		// Reset settings info
		settingsObj.setSettings({ autoAttendance: true });

		// Reset statistical style
		this.totalTimeLearning = 0;
		this.startAttendanceAt = generalMethods.getCurrentTime();
		this.handleChangeClass(membersObj.getCurrentClassInfoName());

		// Reset all attendance style
		this.setStyleAttendance().on();

		this.interval = setInterval(() => {
			// Check has enabled
			if (!settingsObj.getSettings().autoAttendance) return;

			// GENERAL HANDLE
			const membersExistMeetName = [
				...$$(".KsCJ0 .kvLJWc .ZjFb7c"),
			].map((elm) => elm.textContent);

			const studentsExistInfo = this.attendanceData.filter((member) =>
				membersExistMeetName.includes(member.meetName)
			);
			const studentNotExistInfo = this.attendanceData.filter(
				(member) => !membersExistMeetName.includes(member.meetName)
			);
			const settingsBox = $(".settings-box__wrapper");
			const statisticalNav = $(
				`.navigation__list .list__item[data-index="2"]`
			);

			this.totalTimeLearning++;
			this.attendanceData = this.attendanceData.map((member, index) => {
				let memberIsExist;
				let chatContents;
				let currentMicStatus;
				let notExistStatus;
				let isWorkingGroup;
				let isMeetingOwner = false;

				memberIsExist = membersExistMeetName.includes(member.meetName);

				chatContents = [...$$(".YTbUzc")]
					.filter((elm) =>
						member.meetName === $(".ZjFb7c").textContent
							? elm.textContent === "Bạn"
								? true
								: false
							: elm.textContent === member.meetName
					)
					.map((elm) => ({
						time: $(".MuzmKe", elm.parentNode.parentNode)
							.textContent,
						contents: [
							...$$(".Zmm6We > *", elm.parentNode.parentNode),
						].map((elm) => elm.textContent),
					}));

				currentMicStatus = [...$$(".ZjFb7c")].find((elm) => {
					if (elm.textContent === member.meetName) {
						if ($(".QMC9Zd", elm.parentNode)) {
							isMeetingOwner = true;
						}

						return true;
					}

					return false;
				});

				notExistStatus = +$(
					`.not-exist-status__select[data-index="${member.index}"]`
				).value;

				isWorkingGroup = (() => {
					let currentTime = new Date();
					currentTime.setMinutes(
						currentTime.getMinutes() +
							currentTime.getTimezoneOffset()
					);
					currentTime = currentTime.getTime();

					return member.workingGroupTimes.some((groupTimeInfo) => {
						const timeStart = groupTimeInfo.startAt;
						const timeEnd = groupTimeInfo.endAt;

						if (
							currentTime - timeStart >= 0 &&
							currentTime - timeEnd <= 0
						) {
							return true;
						} else {
							return false;
						}
					});
				})();

				if (isMeetingOwner) {
					currentMicStatus = currentMicStatus
						? currentMicStatus.parentNode.parentNode.parentNode.parentNode.querySelector(
								`.JHK7jb.Nep7Ue.I118Fc.FTMc0c`
						  )
							? false
							: true
						: false;
				} else {
					currentMicStatus = currentMicStatus
						? currentMicStatus.parentNode.parentNode.parentNode.parentNode.querySelector(
								`div[jscontroller="e2jnoe"]`
						  )
							? false
							: true
						: false;
				}

				return {
					...member,
					timeLearning: memberIsExist
						? member.timeLearning + 1
						: isWorkingGroup
						? member.timeLearning + 1
						: member.timeLearning,
					learningPercent: memberIsExist
						? Math.floor(
								((member.timeLearning + 1) /
									this.totalTimeLearning) *
									100
						  )
						: Math.floor(
								(member.timeLearning / this.totalTimeLearning) *
									100
						  ),
					isOnline: memberIsExist,
					joinAndExitTimers:
						member.isOnline === memberIsExist
							? member.joinAndExitTimers
							: [
									...member.joinAndExitTimers,
									{
										type: memberIsExist,
										time: generalMethods.getCurrentTime(),
									},
							  ],
					chats: chatContents || [],
					micStatus: currentMicStatus,
					micCount:
						currentMicStatus != member.micStatus &&
						currentMicStatus === true
							? member.micCount + 1
							: member.micCount,
					micDuration: currentMicStatus
						? member.micDuration + 1
						: member.micDuration,
					notExistStatus,
					isWorkingGroup,
				};
			});

			// RENDER VIEW
			// Taskbar left
			renderTaskbarLeftView.call(this);

			// Settings box
			if (
				settingsBox.className.includes("show") &&
				statisticalNav.className.includes("active")
			) {
				renderSettingsBoxView.call(this);
			}

			function renderTaskbarLeftView() {
				const learningTimeConverted = generalMethods.convertTimeSecond(
					this.totalTimeLearning
				);

				this.domVariables.turnOnStateMessageElm().textContent = `${membersObj.getCurrentClassInfoName()} - ${generalMethods.getTimeStr(
					true,
					false,
					false,
					learningTimeConverted
				)} (${studentsExistInfo.length}/${
					this.attendanceData.length
				})`;
			}

			function renderSettingsBoxView() {
				// HANDLE STATISTICAL TAB
				// Time learning handle
				const totalTimeLearningConverted =
					generalMethods.convertTimeSecond(this.totalTimeLearning);

				this.domVariables.totalTimeLearningElm().textContent = `${generalMethods.getTimeStr(
					true,
					false,
					false,
					totalTimeLearningConverted
				)}`;

				// Student exist list handle
				this.domVariables.studentExistListElm().textContent = `${studentsExistInfo.length}/${this.attendanceData.length} HS`;

				// Student not exist box handle
				this.domVariables.notExistStudentBoxLabelELm().textContent = `HS hiện chưa có mặt (${studentNotExistInfo.length})`;

				// Student attendance list info handle
				const settings = settingsObj.getSettings();
				const allSortWrapper = $$(
					`.settings-box__wrapper .tab-list__item.statistical .statistical__slide-3 .slide-3__header label[data-sort-type]`
				);

				let columnSort;
				let sortType;

				allSortWrapper.forEach((sortWapper) => {
					const inputSort = $(`input[type="radio"]`, sortWapper);

					if (inputSort.checked) {
						columnSort = inputSort.value;
						sortType = Number(sortWapper.dataset.sortType);
					}
				});

				[...this.attendanceData]
					.sortObject(columnSort, sortType)
					.forEach((studentInfo, index) => {
						const studentItemElm = $(
							`.student-wrapper__student[data-index="${studentInfo.index}"]`,
							this.domVariables.attendanceListWrapper()
						);
						if (!studentItemElm) return;

						studentItemElm.style.order = index;

						const statusElm = $(
							".student__index > div",
							studentItemElm
						);
						const existBarElm = $(
							".main-bar__current",
							studentItemElm
						);
						const existBarContentElm = $(
							".current__percent",
							studentItemElm
						);
						const firstMeetElm = $(
							".join-and-exit-timers__first p",
							studentItemElm
						);
						const meetTimeList = $(
							".join-and-exit-timers__list",
							studentItemElm
						);
						const timeLearningElm = $(
							".student__time-learning > p",
							studentItemElm
						);
						const timeLearningConverted =
							generalMethods.convertTimeSecond(
								studentInfo.timeLearning
							);

						if (studentInfo.isOnline) {
							statusElm.classList.add("circle--online");
							statusElm.classList.remove("circle--offline");
							statusElm.classList.remove("circle--working-group");
						}

						if (!studentInfo.isOnline) {
							if (studentInfo.isWorkingGroup) {
								statusElm.classList.add("circle--working-group");
								statusElm.classList.remove("circle--online");
								statusElm.classList.remove("circle--offline");
							}

							if (!studentInfo.isWorkingGroup) {
								statusElm.classList.add("circle--offline");
								statusElm.classList.remove("circle--online");
								statusElm.classList.remove(
									"circle--working-group"
								);
							}
						}

						if (
							studentInfo.learningPercent <
							settings.timingExistPercent
						) {
							studentItemElm.classList.add("mark");
						} else {
							studentItemElm.classList.remove("mark");
						}

						existBarElm.style.width = `${studentInfo.learningPercent}%`;
						existBarContentElm.textContent = `${studentInfo.learningPercent}%`;
						firstMeetElm.textContent = `${
							studentInfo.joinAndExitTimers.length
								? generalMethods.getTimeStr(
										true,
										false,
										false,
										studentInfo.joinAndExitTimers[0].time
								  )
								: "Chưa vào"
						}`;

						// In and Out time
						meetTimeList.innerHTML = "";
						studentInfo.joinAndExitTimers.forEach(
							(joinAndExitTime) => {
								const timerItem = document.createElement("li");

								timerItem.className = `list__timers ${
									joinAndExitTime.type === true ? "join" : "exit"
								}`;
								timerItem.innerHTML = `
									<p>${generalMethods.getTimeStr(
										true,
										false,
										false,
										joinAndExitTime.time
									)}</p>
									<i class="${
										joinAndExitTime.type === true
											? "far fa-sign-in-alt"
											: "far fa-sign-out-alt"
									}"></i>
							`;

								meetTimeList.appendChild(timerItem);
							}
						);
						timeLearningElm.textContent = `${generalMethods.getTimeStr(
							true,
							false,
							false,
							timeLearningConverted
						)}`;

						// Exist state select
						const notExistSelectElm = $(
							`select.not-exist-status__select[data-index="${studentInfo.index}"]`
						);

						if (studentInfo.isOnline) {
							notExistSelectElm.innerHTML = `
								<option value="0">Có mặt</option>
							`;

							notExistSelectElm.value = 0;
						}

						if (!studentInfo.isOnline) {
							if (studentInfo.acceptNotExist) {
								notExistSelectElm.innerHTML = `
									<option value="1">K.Phép</option>
									<option value="2">C.Phép</option>
								`;

								notExistSelectElm.value = 2;
							}

							if (!studentInfo.acceptNotExist) {
								notExistSelectElm.innerHTML = `
									<option value="1">K.Phép</option>
									<option value="2">C.Phép</option>
								`;

								notExistSelectElm.value = 1;
							}
						}
					});

				// Slide 4 render view
				const interactiveCtn = $(
					".statistical__slide-4 .slide-4__interactive-ctn .body__interactive-list"
				);

				interactiveCtn.innerHTML = "";

				this.attendanceData.forEach((member) => {
					const newItem = document.createElement("li");

					newItem.className = "interactive-list__item";
					newItem.innerHTML = `
						<div class="item__img-ctn">
							<img src="${getLink(
								"img/student.png"
							)}" alt="" class="item__avatar" data-iml="4769.5">
						</div>
						<div class="item__info-ctn">
							<div class="info-ctn__info">
								<i class="fal fa-graduation-cap"></i>
								<span>Tên: <b>${member.name} (${member.index})</b></span>
							</div>
							<div class="info-ctn__mic">
								<i class="far fa-microphone"></i>
								<span>Mic: <b>${member.micCount}</b> lần - <b>${generalMethods.getTimeStr(
						true,
						false,
						false,
						generalMethods.convertTimeSecond(member.micDuration)
					)}</b></span>
							</div>
							<div class="info-ctn__comment" data-index="${member.index}" data-name="${
						member.name
					}">
								<p style="display: none">${JSON.stringify(member.chats)}</p>
								<i class="far fa-comments-alt"></i>
								<span>
									Chat: <b>${member.chats.reduce(
										(preValue, curValue) =>
											preValue + curValue.contents.length,
										0
									)}</b> lần - Nội dung
									<i class="fas fa-arrow-alt-right" style="margin-right: 3px"></i>
								</span>
							</div>
						</div>`;

					interactiveCtn.appendChild(newItem);
				});
			}
		}, 1000);
	}

	async turnOff() {
		// Attendance history handle
		clearInterval(this.interval);

		attendanceHistoryObj.setHistory([
			...attendanceHistoryObj.getHistory(),
			{
				classInfoName: membersObj.getCurrentClassInfoName(),
				startAttendanceAt: this.startAttendanceAt,
				endAttendanceAt: generalMethods.getCurrentTime(),
				totalTimeLearning: this.totalTimeLearning,
				attendanceData: this.attendanceData,
				chats: await (async function getChats() {
					const allChats = [];
					const allChatsElement = $$(".z38b6 .GDhqjd");

					allChatsElement.forEach((chatElement) => {
						const chatName = $(".YTbUzc", chatElement).textContent;
						const chatTime = $(".MuzmKe", chatElement).textContent;
						const chatContents = Array.from(
							$$(".Zmm6We > *", chatElement)
						).map((elm) => elm.textContent);

						allChats.push({
							name: chatName,
							time: chatTime,
							content: chatContents,
						});
					});

					return allChats;
				})(),
			},
		]);

		// Reset attendance data
		this.attendanceData = this.attendanceData.map((studentInfo) => ({
			index: studentInfo.index,
			name: studentInfo.name,
			meetName: studentInfo.meetName,
			timeLearning: 0,
			percentLearning: 0,
			isOnline: false,
			joinAndExitTimers: [],
			chats: [],
			micStatus: false,
			micCount: 0,
			micDuration: 0,
			notExistStatus: 0 /* 0 -> exit, 1 -> not accept, 2 -> accept */,

			// Group working
			isWorkingGroup: false,
			workingGroupTimes: studentInfo.workingGroupTimes,
		}));

		settingsObj.setSettings({ autoAttendance: false });
		const allExistStatusElm = $$(
			".settings-box__wrapper .table__student-table .student-table__body .body__row .row__exist-status"
		);

		allExistStatusElm.forEach((elm) => {
			elm.textContent = "Chưa bật";
			elm.classList.remove("exist", "not-exist");
		});

		// Reset all attendance style
		this.setStyleAttendance().off();
	}

	setStyleAttendance() {
		const taskbarLeftAttandanceInput = $(
			".taskbar__left .left__attendance-state input"
		);
		const taskbarLeftTurnOnMessageElm = $(
			".taskbar__left .left__attendance-state .attendance-state__attendance-message .attendance-message__on-state p"
		);
		const featuresAttendanceInput = $(
			".settings-box__wrapper .content__tab-list .tab-list__item.features .features__auto-attendance input"
		);

		return {
			on: () => {
				//
				// Reset style statistical tab
				//
				this.domVariables.currentClassElm().textContent =
					membersObj.getCurrentClassInfoName();
				this.domVariables.disabledStatusContentElm().textContent = `Bắt đầu học lúc ${generalMethods.getTimeStr(
					true,
					true,
					true,
					this.startAttendanceAt
				)}`;

				// Reset style attandance btn in features tab
				featuresAttendanceInput.checked = true;

				// Reset style taskbar left
				taskbarLeftAttandanceInput.checked = true;

				this.renderStatisticalAttendanceList();
			},
			off: () => {
				//
				// Reset style statistical tab
				//
				const allStudentsAttendance = $$(
					".slide-3__student-wrapper > *",
					this.domVariables.attendanceListWrapper().parentNode
				);
				const studentsAttendanceWrapper = $$(
					".settings-box__wrapper .tab-list__item.statistical .statistical__slide-3 .slide-3__student-wrapper"
				);
				const statisticalSlide4Elm = $(
					".settings-box__wrapper .slide-4__interactive-ctn .body__interactive-list"
				);

				this.domVariables.disabledStatusContentElm().textContent =
					"Bật điểm danh tự động để bắt đầu thống kê!";
				this.domVariables.currentClassElm().textContent = "...";
				this.domVariables.totalTimeLearningElm().textContent =
					"00:00:00";
				this.domVariables.studentExistListElm().textContent = `... HS`;
				this.domVariables.notExistStudentBoxLabelELm().textContent = `HS hiện chưa có mặt`;
				this.domVariables.attendanceListWrapper().innerHTML = "";
				statisticalSlide4Elm.innerHTML = "";

				allStudentsAttendance.forEach((studentELm) => {
					const studentProgressBar = $(
						".main-bar__current",
						studentELm
					);
					const studentProgressBarText = $(
						"span.current__percent",
						studentELm
					);
					const timeLearningText = $(
						".student__time-learning",
						studentELm
					);

					studentProgressBar.style.width = 0;
					studentProgressBarText.innerText = "0%";
					timeLearningText.innerText = "Chưa điểm danh";
				});

				// Reset style attandance btn in features tab
				featuresAttendanceInput.checked = false;

				// Reset style taskbar left
				taskbarLeftAttandanceInput.checked = false;
				taskbarLeftTurnOnMessageElm.textContent = `Đã học 00:00:00 (0/${this.attendanceData.length})`;
			},
		};
	}

	renderStatisticalAttendanceList(membersList) {
		if (!membersList) {
			membersList = membersObj.getClass().data;
		}

		// Render attendance list
		const attendanceListWrapper =
			this.domVariables.attendanceListWrapper();

		attendanceListWrapper.innerHTML = ``;
		membersList.forEach((studentInfo) => {
			const newStudentAttendanceItem = document.createElement("li");

			newStudentAttendanceItem.dataset.index = studentInfo.index;
			newStudentAttendanceItem.className = "student-wrapper__student";
			newStudentAttendanceItem.innerHTML = `
				<span class="student__is-online">
				</span>
				<span class="student__index">
					<div class="circle circle--offline"></div>
					${studentInfo.index}
				</span>
				<span class="student__name">${studentInfo.name}</span>
				<span class="student__exist-bar">
					<div class="exist-bar__main-bar">
						<div class="main-bar__current" style="width: 0%;"><span class="current__percent">0</span></div>
					</div>
				</span>
				<span class="student__join-and-exit-timers">
					<span class="join-and-exit-timers__first">
						<p>Chưa vào</p>
						<i class="far fa-angle-down"></i>
					</span>
					<ul class="join-and-exit-timers__list">
						<li class="list__timers join">
								<p>00:00:00</p>
								<i class="fas fa-sign-in-alt"></i>
						</li>
						<li class="list__timers exit">
								<p>00:00:00</p>
								<i class="fas fa-sign-out-alt"></i>
						</li>
					</ul>
				</span>
				<span class="student__time-learning"><p>00:00:00</p></span>
				<span class="student__not-exist-status">
					<select class="not-exist-status__select" data-index="${studentInfo.index}">
						
					</select>
				</span>
			`;

			attendanceListWrapper.appendChild(newStudentAttendanceItem);
		});
	}
}
var attendanceObj = new Attendance();
attendanceObj.initial();

class AttendanceHistory {
	getHistory() {
		return (
			JSON.parse(
				localStorage.getItem("googleMeetExtension___Attendance")
			) || []
		);
	}

	setHistory(newHistory) {
		localStorage.setItem(
			"googleMeetExtension___Attendance",
			JSON.stringify(newHistory)
		);

		classPageObj.settingsBox.renderAttendanceHistoryList();
	}

	deleteHistory(historyIndex) {
		const currentHistoryList = this.getHistory();

		currentHistoryList.splice(historyIndex, 1);
		this.setHistory(currentHistoryList);
		classPageObj.settingsBox.renderAttendanceHistoryList();
	}

	renderExcel(attendanceInfo) {
		const renderTableData = document.createElement("table");
		const totalTimeLearningConverted = generalMethods.convertTimeSecond(
			attendanceInfo.totalTimeLearning
		);
		const timeStart = attendanceInfo.startAttendanceAt;
		const timeEnd = attendanceInfo.endAttendanceAt;

		addTableRows(
			renderTableData,
			[`Thông tin điểm danh của lớp ${attendanceInfo.classInfoName}`],
			["Tổng số học sinh", attendanceInfo.attendanceData.length],
			[
				"Bắt đầu điểm danh",
				generalMethods.getTimeStr(true, true, true, timeStart),
			],
			[
				"Kết thúc điểm danh",
				generalMethods.getTimeStr(true, true, true, timeEnd),
			],
			[
				"Thời gian",
				generalMethods.getTimeStr(
					true,
					false,
					false,
					totalTimeLearningConverted
				),
			],
			[""],
			[""],
			["STT", "Họ và tên", "Tên trong Google meet", "Thời gian"],
			...attendanceInfo.attendanceData.map((studentInfo) => [
				studentInfo.index,
				studentInfo.name,
				studentInfo.meetName,
				(() => {
					const timeLearningConverted =
						generalMethods.convertTimeSecond(
							studentInfo.timeLearning
						);

					return generalMethods.getTimeStr(
						true,
						false,
						false,
						timeLearningConverted
					);
				})(),
			])
		);

		function addTableRows(table, ...dataArrayArguments) {
			dataArrayArguments.forEach((dataArray) => {
				const row = document.createElement("tr");

				dataArray.forEach((data) => {
					const rowColumn = document.createElement("td");

					rowColumn.textContent = data;
					row.appendChild(rowColumn);
				});

				table.appendChild(row);
			});
		}
		function html_table_to_excel(dataTableELm) {
			const type = "xlsx";
			const data = dataTableELm;
			const file = XLSX.utils.table_to_book(data, {
				sheet: "sheet1",
			});

			XLSX.write(file, {
				bookType: type,
				bookSST: true,
				type: "base64",
			});

			XLSX.writeFile(
				file,
				`${
					attendanceInfo.classInfoName
				} - Điểm danh lúc ${generalMethods.getTimeStr(
					true,
					true,
					true,
					timeStart
				)}.${type}`
			);
		}
		html_table_to_excel(renderTableData);
	}

	async renderAttendancePage(attendanceData) {
		const totalTimeLearningConverted = generalMethods.convertTimeSecond(
			attendanceData.totalTimeLearning
		);
		const settings = settingsObj.getSettings();
		const studentsExistCount = attendanceData.attendanceData.reduce(
			(previousCount, studentInfo) =>
				Math.floor(
					(studentInfo.timeLearning /
						attendanceData.totalTimeLearning) *
						100
				) >= settings.timingExistPercent
					? previousCount + 1
					: previousCount,
			0
		);

		this.currentWindow?.close();
		this.currentWindow = window.open("");

		const cssStyleFilePath = chrome.runtime.getURL(
			"css/attendancePage.css"
		);
		const windowTitle = `${membersObj.getCurrentClassInfoName()} - Điểm danh lúc ${generalMethods.getTimeStr(
			true,
			true,
			true,
			attendanceData.startAttendanceAt
		)}`;

		this.currentWindow.document.write(`
			<!DOCTYPE html>
				<html lang="en">
					<head>
						<meta charset="UTF-8" />
						<meta http-equiv="X-UA-Compatible" content="IE=edge" />
						<meta name="viewport" content="width=device-width, initial-scale=1.0" />
						<link rel="stylesheet" href="${cssStyleFilePath}" />
						<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />
						<title>${windowTitle}</title>
					</head>
					<body onblur="self.focus();">
						<div class="cmt-box-wrapper">
							<div class="cmt-box-wrapper__background"></div>
							<div class="cmt-box-wrapper__box">
								<header class="box__header">
									<p>Lịch sử tin nhắn</p>
									<p></p>
								</header>

								<div class="box__body">
									<ul class="body__cmt-list"></ul>
								</div>
							</div>
						</div>

						<div class="attendance-page">
								<button class="attendance-page__print-btn">
									<img src="${getLink("img/printIcon.png")}" alt=""/>
									<p>Lưu lại</p>
								</button>
								<div class="attendance-page__state-message"><img src="${getLink(
									"img/toggleIcon.png"
								)}" alt=""/> <span>Bắt đầu điểm danh lúc ${generalMethods.getTimeStr(
			true,
			true,
			true,
			attendanceData.startAttendanceAt
		)}</span></div>
								<div class="attendance-page__slide-1">
									<div class="slide-1__class-info-name">
										<h2 class="class-info-name__class-name">${
											attendanceData.classInfoName
										}</h2>
										<span class="class-info-name__label">Lớp hiện tại</span>
									</div>
									<div class="slide-1__time-learning">
										<h2 class="time-learning__time">${totalTimeLearningConverted.hours}:${
			totalTimeLearningConverted.minutes
		}:${totalTimeLearningConverted.seconds}</h2>
										<span class="time-learning__label">Thời gian</span>
									</div>
									<div class="slide-1__student-exist-count">
										<h2 class="student-exist-count__count">${studentsExistCount} HS</h2>
										<span class="student-exist-count__label">Đi học đủ</span>
									</div>
								</div>
								<div class="attendance-page__slide-2">
									<div class="slide-2__not-exist-student">
										<h2 class="not-exist-student__caption">HS vắng trong buổi học (${
											attendanceData.attendanceData.length -
											studentsExistCount
										})</h2>
										<div class="not-exist-student__box"></div>
									</div>
								</div>
								<div class="attendance-page__slide-3">
									<h2 class="slide-3__caption">Thống kê chi tiết</h2>
									<div class="slide-3__header">
										<div class="header__index">
												<span class="index__title">STT</span>
												<label class="index__sort" data-sort-type="0">
													<input type="radio" name="sort-column" value="index" checked />
													<i class="fas fa-sort-alpha-down"></i>
													<i class="fas fa-sort-alpha-down-alt"></i>
												</label>
										</div>
										<div class="header__name"><span class="name__title">Họ và tên</span></div>
										<div class="header__exist-bar">
											<span class="exist-bar__title">Phần trăm có mặt</span>
										</div>
										<div class="header__join-and-exit-timers"><span class="join-and-exit-timers__title">Vào học lúc</span></div>
										<div class="header__time-learning">
												<span class="time-learning__title">Thời gian</span>
												<label class="time-learning__sort" data-sort-type="0">
													<input type="radio" name="sort-column" value="timeLearning" />
													<i class="fas fa-sort-alpha-down"></i>
													<i class="fas fa-sort-alpha-down-alt"></i>
												</label>
										</div>
										<div class="header__not-exist-status">
											<span>Điểm danh</span>
										</div>
									</div>
									<ul class="slide-3__student-wrapper"></ul>
								</div>
								<div class="attendance-page__slide-4">
									<div class="slide-4__chat-img"><img src="${getLink(
										"img/chat-thumb.svg"
									)}" alt=""/></div>
									<div class="slide-4__chat-ctn">
										<div class="chat-ctn__head"><p>Tin nhắn trong lớp học</p></div>
										<div class="chat-ctn__body">
												<ul class="body__chat-ctn">
													${attendanceData.chats
														.map(
															(chatInfo) => `
													<li class="chat-ctn__chat-item">
														<div class="chat-item__info"><span class="name">${
															chatInfo.name
														}</span><time>${
																chatInfo.time
															}</time></div>
														<div class="chat-item__content-list">
																${chatInfo.content
																	.map(
																		(chatContent) => `
																<p class="content-list__content">${chatContent}</p>
																`
																	)
																	.join("")}
														</div>
													</li>
													`
														)
														.join("")}
												</ul>
										</div>
									</div>
								</div>

								<div class="attendance-page__slide-5">
									<div class="slide-5__interactive-ctn">
										<header class="interactive-ctn__head">
											<p>Thống kê tương tác</p>
										</header>
						
										<div class="interactive-ctn__body">
											<ul class="body__interactive-list">
												${attendanceData.attendanceData
													.map(
														(member) => `
													<li class="interactive-list__item">
														<div class="item__img-ctn">
															<img src="${getLink("img/student.png")}" alt="" class="item__avatar" />
														</div>
														<div class="item__info-ctn">
															<div class="info-ctn__info">
																<i class="fal fa-graduation-cap"></i>
																<span>Tên: <b>${member.name} (${member.index})</b></span>
															</div>
															<div class="info-ctn__mic">
																<i class="far fa-microphone"></i>
																<span>Mic: <b>${member.micCount}</b> lần - <b>${generalMethods.getTimeStr(
															true,
															false,
															false,
															generalMethods.convertTimeSecond(
																member.micDuration
															)
														)}</b></span>
															</div>
															<div class="info-ctn__comment" data-name="${member.name}">
																<p style="display: none">${JSON.stringify(member.chats)}</p>
																<i class="far fa-comments-alt"></i>
																<span>
																	Chat: <b>${member.chats.reduce(
																		(
																			accumanlator,
																			currentValue
																		) =>
																			accumanlator +
																			currentValue
																				.contents
																				.length,
																		0
																	)}</b> lần - Nội dung
																	<i class="fas fa-arrow-alt-right" style="margin-right: 3px"></i>
																</span>
															</div>
														</div>
													</li>	`
													)
													.join("")}
											</ul>
										</div>
									</div>
								</div>
						</div>
					</body>
				</html>		
		`);

		// Set event cmt box wrapper
		const interactiveCtn = $(
			".attendance-page__slide-5 .slide-5__interactive-ctn",
			this.currentWindow.document
		);
		const cmtBoxBackgroundElm = $(
			".cmt-box-wrapper__background",
			this.currentWindow.document
		);
		const cmtBoxElm = $(".cmt-box-wrapper", this.currentWindow.document);

		cmtBoxBackgroundElm.addEventListener("click", (e) => {
			cmtBoxElm.classList.remove("show");
		});

		interactiveCtn.addEventListener("click", (e) => {
			let target = e.target;

			while (
				!target.className.split(" ").includes("info-ctn__comment") ||
				target.className
					.split(" ")
					.includes("slide-5__interactive-ctn")
			) {
				target = target.parentNode;
			}

			const headerNameElm = $(".box__header p:last-child", cmtBoxElm);
			const cmtListElm = $(".body__cmt-list", cmtBoxElm);
			const chatsData = JSON.parse($("p", target).textContent);
			let cmtItemsHtml = "";

			headerNameElm.textContent = target.dataset.name;
			chatsData.forEach((chat) => {
				const time = chat.time;

				cmtItemsHtml += chat.contents
					.map(
						(content, index, originArr) =>
							`<li class="cmt-list__cmt ${
								index === 0 ? "first" : ""
							} ${index === originArr.length - 1 ? "last" : ""}">
								<span>${content}</span>
								<time>${time}</time>
							</li>`
					)
					.join("");
			});

			cmtListElm.innerHTML = cmtItemsHtml;
			cmtBoxElm.classList.add("show");
		});

		const notExistStudentsBox = $(
			".not-exist-student__box",
			this.currentWindow.document
		);
		const notExistStudentsInfo = attendanceData.attendanceData.filter(
			(studentInfo) =>
				studentInfo.learningPercent < settings.timingExistPercent
		);

		notExistStudentsInfo.forEach((studentInfo) => {
			const newStudentInfoElm = document.createElement("div");

			newStudentInfoElm.className = "box__item";
			newStudentInfoElm.innerHTML = `<span class="item__index"> <p>${studentInfo.index}</p></span><span class="item__name"> <p>${studentInfo.name}</p></span>`;

			notExistStudentsBox.appendChild(newStudentInfoElm);
		});

		// Set event print button
		const printBtn = $(
			".attendance-page__print-btn",
			this.currentWindow.document
		);

		printBtn.addEventListener("click", () => this.currentWindow.print());

		// Render attendance info
		const attendanceListWrapper = $(
			".slide-3__student-wrapper",
			this.currentWindow.document
		);

		// Sort the attendance list
		const indexSortBtn = $(
			".attendance-page__slide-3 .slide-3__header .index__sort",
			this.currentWindow.document
		);
		const timeLearningSortBtn = $(
			".attendance-page__slide-3 .slide-3__header .time-learning__sort",
			this.currentWindow.document
		);

		indexSortBtn.addEventListener(
			"click",
			handleClickSortBtns.bind(this)
		);
		timeLearningSortBtn.addEventListener(
			"click",
			handleClickSortBtns.bind(this)
		);

		function handleClickSortBtns(e) {
			e.preventDefault();
			let currentBtn = e.target;

			while (currentBtn.tagName != "LABEL") {
				currentBtn = currentBtn.parentNode;
			}

			const sortInput = $(`input[type="radio"]`, currentBtn);
			const allSortWrapper = Array.from(
				$$(
					".attendance-page__slide-3 .slide-3__header label",
					this.currentWindow.document
				)
			);

			allSortWrapper
				.filter((labelElm) => {
					const inputSortInCurrentLabel = $(
						`input[type="radio"]`,
						labelElm
					);

					return !(sortInput === inputSortInCurrentLabel);
				})
				.forEach((labelElm) => {
					labelElm.dataset.sortType = 0;
				});

			if (sortInput.checked) {
				currentBtn.dataset.sortType =
					currentBtn.dataset.sortType == 0 ? 1 : 0;
			} else {
				sortInput.checked = true;
			}

			handleSort.call(this);
		}

		handleSort.call(this);
		function handleSort() {
			const allSortWrapper = [
				...$$(
					".attendance-page__slide-3 .slide-3__header label[data-sort-type]",
					this.currentWindow.document
				),
			];
			let sortField;
			let sortType;

			allSortWrapper.some((wrapperElm) => {
				const inputSort = $(`input[type="radio"]`, wrapperElm);

				if (inputSort.checked) {
					sortField = inputSort.value;
					sortType = +wrapperElm.dataset.sortType;

					return true;
				}

				return false;
			});

			attendanceListWrapper.innerHTML = "";

			attendanceData.attendanceData
				.sortObject(sortField, sortType)
				.forEach((studentInfo) => {
					const newStudentAttendanceItem =
						document.createElement("li");
					const timeLearningConverted =
						generalMethods.convertTimeSecond(
							studentInfo.timeLearning
						);
					const learningPercent = Math.floor(
						(studentInfo.timeLearning /
							attendanceData.totalTimeLearning) *
							100
					);

					newStudentAttendanceItem.className = `student-wrapper__student${
						learningPercent < settings.timingExistPercent
							? " mark"
							: ""
					}`;
					newStudentAttendanceItem.innerHTML = `<span class="student__index">${
						studentInfo.index
					}</span><span class="student__name">${
						studentInfo.name
					}</span><span class="student__exist-bar"><div class="exist-bar__main-bar"><span class="main-bar__left"></span><div class="main-bar__current" style="width: ${learningPercent}%"><span class="current__percent">${learningPercent}%</span></div><span class="main-bar__right"></span></div></span><span class="student__join-and-exit-timers"><span class="join-and-exit-timers__first"><p>${
						studentInfo.joinAndExitTimers.length
							? generalMethods.getTimeStr(
									true,
									false,
									false,
									studentInfo.joinAndExitTimers[0].time
							  )
							: "Chưa vào"
					}</p><i class="far fa-angle-down"></i></span><ul class="join-and-exit-timers__list">${studentInfo.joinAndExitTimers
						.map(
							(joinAndExitTimer) =>
								`<li class="list__timers ${
									joinAndExitTimer.type ? "join" : "exit"
								}"><p>${generalMethods.getTimeStr(
									true,
									false,
									false,
									joinAndExitTimer.time
								)}</p><i class="${
									joinAndExitTimer.type
										? "fas fa-sign-in-alt"
										: "fas fa-sign-out-alt"
								}"></i></li>`
						)
						.join(
							""
						)}</ul></span><span class="student__time-learning"><p>${generalMethods.getTimeStr(
						true,
						false,
						false,
						timeLearningConverted
					)}</p></span><span class="student__not-exist-status"><p>${
						studentInfo.notExistStatus === 0
							? "Có mặt"
							: studentInfo.notExistStatus === 1
							? "Không phép"
							: "Có phép"
					}</p></span>`;

					attendanceListWrapper.appendChild(newStudentAttendanceItem);
				});
		}

		await generalMethods.sleep(1000);

		this.currentWindow.addEventListener("beforeprint", (e) => {
			// Set margin top to next page if elm over current page
			// Slide 3
			const studentListElm = $$(
				".slide-3__student-wrapper > .student-wrapper__student",
				this.currentWindow.document
			);

			studentListElm.forEach((studentItemElm) => {
				const studentItemElmOffsetTop =
					studentItemElm.offsetTop % 1200;
				const studentItemElmHeight = studentItemElm.clientHeight;

				if (studentItemElmOffsetTop + studentItemElmHeight > 1200) {
					studentItemElm.style.marginTop = `${
						1200 + 2 - studentItemElmOffsetTop
					}px`;
				}
			});

			// Slide 4
			const allMessageContentElm = $$(
				".chat-ctn__chat-item p.content-list__content",
				this.currentWindow.document
			);

			allMessageContentElm.forEach((messageContentElm) => {
				const messageContentElmOffsetTop =
					messageContentElm.offsetTop % 1200;
				const messageContentElmClientHeight =
					messageContentElm.clientHeight;

				console.log(messageContentElm);

				if (
					messageContentElmOffsetTop + messageContentElmClientHeight >
					1190
				) {
					messageContentElm.style.marginTop = `${100}px !important`;
				}
			});
		});
		this.currentWindow.addEventListener("afterprint", (e) => {
			const studentListElm = $$(
				".slide-3__student-wrapper > .student-wrapper__student",
				this.currentWindow.document
			);

			printBtn.style.display = "flex";
			studentListElm.forEach(
				(studemtItemElm) => (studemtItemElm.style.marginTop = "0px")
			);
		});

		return this.currentWindow;
	}

	async renderPdf(attendanceData) {
		const attendanceWindow = await this.renderAttendancePage(
			attendanceData
		);

		attendanceWindow.print();
	}
}
var attendanceHistoryObj = new AttendanceHistory();

class Speaker {
	initial() {
		const speakerInputState = $("#speaker-input");

		speakerInputState.addEventListener("change", (e) => {
			if (e.target.checked) this.on();
			else this.off();
		});
	}

	on() {
		clearInterval(this.funcInterval);

		const allAudioElm = $$("audio");

		allAudioElm.forEach((audioElm) => (audioElm.muted = false));
	}

	off() {
		mute();

		this.funcInterval = setInterval(mute, 100);

		function mute() {
			const allAudioElm = $$("audio");

			allAudioElm.forEach((audioElm) => (audioElm.muted = true));
		}
	}
}
const speakerObj = new Speaker();

class Navigation {
	joinPageElm = () => $(".oZ3U3b.vWXIE");
	classPageElm = () =>
		$(".VfPpkd-Bz112c-LgbsSe.yHy1rc.eT1oJ.tWDL4c.uaILN");
	startPageElm = () => $(".uTbUHc");

	async getCurrentPage() {
		if (this.joinPageElm()) return "joinPage";
		if (this.classPageElm()) return "classPage";
		if (this.startPageElm()) return "startPage";

		await generalMethods.sleep(100);
		return this.getCurrentPage();
	}
}
var navigationObj = new Navigation();

class Main {
	currentPage;

	async run() {
		this.currentPage = await navigationObj.getCurrentPage();
		switch (this.currentPage) {
			case "startPage":
				break;
			case "joinPage":
				joinPageObj.initial();
				break;
			case "classPage":
				classPageObj.initial();
				break;
			default: {
			}
		}
	}
}
var mainObj = new Main();

class JoinPage {
	initial() {
		const settings = settingsObj.getSettings();

		if (settings.autoTurnOffMedia) {
			this.turnOffMedia();
		}
		this.listenGoToClassPage();
	}

	turnOffMedia() {
		(function turnOffVoice() {
			const VOICE_BTN_CLASS =
				".ZB88ed .U26fgb.JRY2Pb.mUbCce.kpROve.yBiuPb.y1zVCf.M9Bg4d.HNeRed";
			const VOICE_BTN_ACTIVE_CLASS =
				".ZB88ed .U26fgb.JRY2Pb.mUbCce.kpROve.yBiuPb.y1zVCf.M9Bg4d.FTMc0c.N2RpBe.jY9Dbb";
			const END_CALL_BTN_CLASS = ".cZG6je .NHaLPe.kEoTPd";

			return generalMethods.domHandleWithCondition(
				VOICE_BTN_CLASS,
				() => $(VOICE_BTN_ACTIVE_CLASS) || $(END_CALL_BTN_CLASS),
				100,
				(element) => element.click()
			);
		})();

		(function turnOffCamera() {
			const CAMERA_BTN_CLASS =
				".GOH7Zb .U26fgb.JRY2Pb.mUbCce.kpROve.yBiuPb.y1zVCf.M9Bg4d.HNeRed";
			const CAMERA_BTN_ACTIVE_CLASS =
				".GOH7Zb .U26fgb.JRY2Pb.mUbCce.kpROve.yBiuPb.y1zVCf.M9Bg4d.FTMc0c.N2RpBe.jY9Dbb";
			const END_CALL_BTN_CLASS = ".cZG6je .NHaLPe.kEoTPd";

			return generalMethods.domHandleWithCondition(
				CAMERA_BTN_CLASS,
				() => $(CAMERA_BTN_ACTIVE_CLASS) || $(END_CALL_BTN_CLASS),
				100,
				(element) => element.click()
			);
		})();
	}

	listenGoToClassPage() {
		const interval = setInterval(async () => {
			if (mainObj.currentPage != "classPage") {
				mainObj.currentPage = await navigationObj.getCurrentPage();
			} else {
				clearInterval(interval);
				mainObj.run();
			}
		}, 200);
	}
}
var joinPageObj = new JoinPage();

class ClassPage {
	async initial() {
		if (this.extensionWasUsed()) return;

		this.openTabs();
		this.setEvent();
		this.turnOffMedia();
		this.taskBar.initial();
		this.settingsBox.initial();
		this.cmtListContainer.initial();
		this.createGroupBox.initial();
		this.undoAndRedoMembersList.initial();
	}

	extensionWasUsed() {
		const usedStateIdStorage = "googleMeetExtension___classPageState";
		const currentLocalStorage = JSON.parse(
			localStorage.getItem(usedStateIdStorage)
		);

		if (currentLocalStorage === null) {
			localStorage.setItem(usedStateIdStorage, "true");
			return false;
		}

		if (currentLocalStorage) return true;
		else {
			localStorage.setItem(usedStateIdStorage, "true");
			return false;
		}
	}

	async openTabs() {
		const OPEN_MEMBER_LIST_BTN_CLASS =
			".r6xAKc:nth-child(2) .VfPpkd-Bz112c-LgbsSe.yHy1rc.eT1oJ.JsuyRc.boDUxc";
		const CLOSE_MENU_LIST_BTN_CLASS = `.WUFI9b[data-tab-id="1"] .VfPpkd-Bz112c-LgbsSe`;

		await generalMethods.domHandleWithCondition(
			OPEN_MEMBER_LIST_BTN_CLASS,
			() => {
				const closeMenuListBtn = $(CLOSE_MENU_LIST_BTN_CLASS);

				return closeMenuListBtn;
			},
			1000,
			(element) => element.click()
		);

		const OPEN_CHAT_BTN_CLASS =
			".r6xAKc:nth-child(3) .VfPpkd-Bz112c-LgbsSe.yHy1rc.eT1oJ.JsuyRc.boDUxc";
		const CLOSE_CHAT_BTN_CLASS = `.WUFI9b[data-tab-id="2"] .VfPpkd-Bz112c-LgbsSe`;

		await generalMethods.domHandleWithCondition(
			OPEN_CHAT_BTN_CLASS,
			() => {
				const closeChatBoardBtn = $(CLOSE_CHAT_BTN_CLASS);

				return closeChatBoardBtn;
			},
			1000,
			(element) => element.click()
		);
	}

	turnOffMedia() {
		// check
		const settings = settingsObj.getSettings();
		if (!settings.autoTurnOffMedia) return;

		// handle
		const microBtnClass =
			".VfPpkd-Bz112c-LgbsSe.yHy1rc.eT1oJ.tWDL4c.uaILN.bPEdgb.qIiG8c";
		const microBtnDisabledClass =
			".VfPpkd-Bz112c-LgbsSe.yHy1rc.eT1oJ.tWDL4c.uaILN.bPEdgb.qIiG8c.FTMc0c.N2RpBe.jY9Dbb";
		const videoBtnClass =
			".VfPpkd-Bz112c-LgbsSe.yHy1rc.eT1oJ.tWDL4c.uaILN.bPEdgb.AAU0Jf";
		const videoBtnDisabledClass =
			".VfPpkd-Bz112c-LgbsSe.yHy1rc.eT1oJ.tWDL4c.uaILN.bPEdgb.AAU0Jf.FTMc0c.N2RpBe.jY9Dbb";

		// micro
		generalMethods.domHandleWithCondition(
			microBtnClass,
			() => $(microBtnDisabledClass),
			100,
			(microBtn) => microBtn.click()
		);

		// video
		generalMethods.domHandleWithCondition(
			videoBtnClass,
			() => $(videoBtnDisabledClass),
			100,
			(videoBtn) => videoBtn.click()
		);
	}

	async setEvent() {
		//
		// Submit attendance when called end
		//
		const END__CALL__BTN__CLASS =
			".VfPpkd-Bz112c-LgbsSe.yHy1rc.eT1oJ.tWDL4c.jh0Tpd.Gt6sbf.QQrMi";
		let endCallBtnElm = $(END__CALL__BTN__CLASS);

		if (!endCallBtnElm) {
			await generalMethods.domHandleWithCondition(
				END__CALL__BTN__CLASS,
				() => {
					console.log($(END__CALL__BTN__CLASS));
					return $(END__CALL__BTN__CLASS);
				},
				50,
				(endCallBtn) => {
					console.log(endCallBtn);
					endCallBtnElm = endCallBtn;
					console.log(endCallBtnElm);
				}
			);
		}

		const isRoomOwer = [...$$(".KV1GEc .cylMye .KsCJ0 ")].some(
			(wrapperMeetNameElm) =>
				$(".GKzAbe", wrapperMeetNameElm) &&
				$(".QMC9Zd", wrapperMeetNameElm)
		);

		window.addEventListener("beforeunload", submitAttendanceHandle);

		endCallBtnElm.addEventListener("click", async (e) => {
			if (isRoomOwer) {
				const END__CALL__BTNS__CLASS = ".CwaK9 .RveJvd.snByac";
				const CLOSE__MENU__BTN__CLASS = ".uArJ5e.Y5FYJe.cjq2Db.IOMpW";
				const BACKGROUND__ELM__CLASS = ".mjANdc.eEPege";

				let endCallBtns = await generalMethods.getDom(
					END__CALL__BTNS__CLASS,
					true,
					30
				);
				let closeMenuBtn = await generalMethods.getDom(
					CLOSE__MENU__BTN__CLASS,
					false,
					30
				);
				let backgroundElm = await generalMethods.getDom(
					BACKGROUND__ELM__CLASS,
					false,
					30
				);

				endCallBtns.forEach((button) => {
					button.addEventListener("click", submitAttendanceHandle);
				});

				closeMenuBtn.addEventListener("click", notEndCallHandle);

				backgroundElm.addEventListener("click", notEndCallHandle);

				function notEndCallHandle() {
					closeMenuBtn.removeEventListener("click", notEndCallHandle);

					backgroundElm.removeEventListener(
						"click",
						notEndCallHandle
					);

					endCallBtns.forEach((button) => {
						button.removeEventListener(
							"click",
							submitAttendanceHandle
						);
					});
				}
			} else {
				submitAttendanceHandle();
			}
		});

		function submitAttendanceHandle(e) {
			// Set used state extension
			const usedStateIdStorage = "googleMeetExtension___classPageState";
			localStorage.setItem(usedStateIdStorage, "false");

			const settings = settingsObj.getSettings();

			if (settings.autoAttendance) {
				// Add current attendance data to history
				attendanceHistoryObj.setHistory([
					...attendanceHistoryObj.getHistory(),
					{
						classInfoName: membersObj.getCurrentClassInfoName(),

						startAttendanceAt: attendanceObj.startAttendanceAt,

						endAttendanceAt: generalMethods.getCurrentTime(),

						totalTimeLearning: attendanceObj.totalTimeLearning,

						attendanceData: attendanceObj.attendanceData,

						chats: (function getChats() {
							const allChats = [];
							const allChatsElement = $$(".z38b6 .GDhqjd");

							allChatsElement.forEach((chatElement) => {
								const chatName = $(
									".YTbUzc",
									chatElement
								).textContent;
								const chatTime = $(
									".MuzmKe",
									chatElement
								).textContent;
								const chatContents = Array.from(
									$$(".Zmm6We > *", chatElement)
								).map((elm) => elm.textContent);

								allChats.push({
									name: chatName,
									time: chatTime,
									content: chatContents,
								});
							});

							return allChats;
						})(),
					},
				]);

				// Turn off auto attendance if it was turned on
				settingsObj.setSettings({ autoAttendance: false });
			}
		}
	}

	cmtListContainer = {
		initial() {
			const body = document.body;
			const cmtBoxContainer = document.createElement("div");

			cmtBoxContainer.className = "cmt-box-wrapper";
			cmtBoxContainer.innerHTML = `
				<div class="cmt-box-wrapper__background"></div>
				<div class="cmt-box-wrapper__box">
					<header class="box__header">
						<p>Lịch sử tin nhắn</p>
						<p>Trần Văn Còn</p>
					</header>

					<div class="box__body">
						<ul class="body__cmt-list"></ul>
					</div>
				</div>
			`;

			const background = $(
				".cmt-box-wrapper__background",
				cmtBoxContainer
			);

			background.addEventListener("click", () => {
				cmtBoxContainer.classList.remove("show");
			});

			body.appendChild(cmtBoxContainer);
		},
	};

	createGroupBox = {
		storageKey: "googleMeetExtension___GroupStorage",

		initial() {
			const body = document.body;

			const createGroupBox = document.createElement("div");

			createGroupBox.id = "create-group-box";
			createGroupBox.className = "create-group-box";
			createGroupBox.innerHTML = `
				<input id="create-group-box-status" type="checkbox" />

				<input id="group-box-type" type="text" value="" />
			
				<label class="create-group-box__background" for="create-group-box-status"></label>

				<div class="create-group-box__box">
					<header class="box__header">
						<p>Tạo nhóm mới</p>
						<button class="header__create-btn">Tạo</button>
					</header>
					<div class="box__body">
						<div class="body__group-info">
							<div class="group-info__group-name">
								<label for="group-name-input">Tên nhóm</label>
								<input id="group-name-input" type="text" />
							</div>

							<div class="group-info__group-class">
								<span>Thuộc lớp</span>
								<i class="fas fa-sort-down"></i>
								<select id="group-class-select"></select>
							</div>

							<div class="group-info__group-start-time">
								<p>Bắt đầu</p>
								<input id="group-time-start-input" type="datetime-local" />
							</div>

							<div class="group-info__group-end-time">
								<p>Thời hạn</p>
								<i class="fas fa-sort-down"></i>
								<select>
									<option value="3">3 phút</option>
									<option value="5">5 phút</option>
									<option value="7">7 phút</option>
									<option value="10">10 phút</option>
									<option value="15">15 phút</option>
									<option value="30">30 phút</option>
									<option value="45">45 phút</option>
									<option value="60">1 giờ</option>
									<option value="120">2 giờ</option>
									<option value="360">6 giờ</option>
								</select>
							</div>

							<div class="group-info__subjects">
								<p>Môn học</p>
								<i class="fas fa-sort-down"></i>
								<select id="group-subjects-select">
									<option value="Tin học">Tin học</option>
									<option value="Toán">Toán</option>
									<option value="Tiếng anh">Tiếng anh</option>
									<option value="Ngữ văn">Ngữ văn</option>
									<option value="Lịch sử">Lịch sử</option>
									<option value="Địa lí">Địa lí</option>
									<option value="Vật lí">Vật lí</option>
									<option value="Hóa học">Hóa học</option>
									<option value="Sinh học">Sinh học</option>
									<option value="Công nghệ">Công nghệ</option>
									<option value="GDCD">GDCD</option>
									<option value="Quốc phòng">Quốc phòng</option>
									<option value="Thể dục">Thể dục</option>
									<option value="Khác">Khác</option>
								</select>
							</div>
						</div>

						<div class="body__search-box">
							<div class="search-box__input-ctn">
								<input type="search" placeholder="Tìm kiếm theo tên" />
								<i class="far fa-search"></i>
							</div>
						</div>

						<div class="body__student-list-ctn">
							<ul class="student-list-ctn__list"></ul>
						</div>
					</div>
				</div>
			`;

			body.appendChild(createGroupBox);

			this.createGroupBox = createGroupBox;
			this.initEvent();
			this.initGroupStorage();
			this.renderGroupListInSettingsBox();
			this.createGroupHandle();
		},

		initEvent() {
			// Change group class handle
			const groupClassSelect = $(
				"#create-group-box .group-info__group-class select"
			);
			groupClassSelect.addEventListener("change", (e) =>
				this.renderMembersList(e.target.value)
			);

			// Listen event click in list group wrapper
			const tableListGroupWrapper = $("#group-tab .table__body");
			tableListGroupWrapper.addEventListener("click", (e) => {
				let target = e.target;

				const classNameArr = [
					"table__body",
					"body__row",
					"members-count",
					"fas fa-share",
					"fas fa-edit",
					"fas fa-trash",
				];

				while (!classNameArr.includes(target.className)) {
					target = target.parentNode;
				}

				if (
					target.className.includes("table__body") ||
					target.className.includes("body__row")
				)
					return;

				let tableRow = e.target;
				while (!tableRow.className.includes("body__row")) {
					tableRow = tableRow.parentNode;
				}

				if (target.className.includes("members-count")) {
					const eventId = tableRow.dataset.eventId;

					this.openToChange(eventId);
				}

				if (target.className.includes("fa-trash")) {
					const eventId = tableRow.dataset.eventId;

					this.deleteGroup(eventId);
				}

				if (target.className.includes("fa-edit")) {
					const eventId = tableRow.dataset.eventId;

					this.openToChange(eventId);
				}

				if (target.className.includes("fa-share")) {
					const eventId = tableRow.dataset.eventId;
					const textToShare = this.getIntroducetext(eventId);

					navigator.clipboard.writeText(textToShare);

					alert(
						"Tin nhắn chia sẻ đã được copy vào bộ nhớ máy!\n\nChuột phải chọn Dán(Paste) hoặc nhấn Crtl + V để chia sẻ!"
					);
				}
			});

			// Listen event type of search box
			const createGroupSearchBox = $(
				"#create-group-box .create-group-box__box .body__search-box input"
			);
			createGroupSearchBox.addEventListener("input", (e) => {
				const value = e.target.value.toLowerCase();

				const allStudentRowToSearch = [
					...$$(
						"#create-group-box .create-group-box__box .student-list-ctn__list .list__student"
					),
				];
				const allStudentSearchContent = allStudentRowToSearch.map(
					(studentRow) => ({
						index: +studentRow.dataset.index,
						searchContent: $("span", studentRow).textContent,
					})
				);

				const studentsIndexShowed = allStudentSearchContent
					.filter((searchContent) =>
						searchContent.searchContent.toLowerCase().includes(value)
					)
					.map((searchContent) => searchContent.index);

				allStudentRowToSearch.forEach((studentRow) => {
					const studentIndex = +studentRow.dataset.index;

					if (studentsIndexShowed.includes(studentIndex)) {
						studentRow.style.height = "40px";
					} else {
						studentRow.style.height = "0px";
					}
				});
			});
		},

		createGroupHandle() {
			const createGroupBtn = $(
				".header__create-btn",
				this.createGroupBox
			);

			createGroupBtn.addEventListener("click", async (e) => {
				const groupNameInput = $("#group-name-input");
				const groupStartMeetingInput = $("#group-time-start-input");
				const membersCount = $$(
					"#create-group-box .body__student-list-ctn .list__student input:checked"
				).length;

				if (!groupNameInput.value.length) {
					alert("Vui lòng nhập tên nhóm cần tạo!");
					return;
				}

				if (!groupStartMeetingInput.value) {
					alert("Vui lòng chọn thời gian bắt đầu!");
					return;
				}

				if (membersCount === 0) {
					alert(
						"Vui chọn ít nhất 1 thành viên để bắt đầu buổi thảo luận!"
					);
					return;
				}

				const groupClass = $("#group-class-select").value;

				const meetingDuration = $(
					".group-info__group-end-time select",
					this.createGroupBox
				).value;

				let startAt = new Date($("#group-time-start-input").value);
				startAt.setMinutes(
					startAt.getMinutes() + startAt.getTimezoneOffset()
				);
				startAt = startAt.getTime();

				let endAt = new Date(startAt.valueOf());
				endAt.setMinutes(endAt.getMinutes() + +meetingDuration);
				endAt = endAt.getTime();

				const membersListIndex = [
					...$$(
						".body__student-list-ctn .student-list-ctn__list .list__student",
						this.createGroupBox
					),
				]
					.filter((elm) => $(`input[type="checkbox"]`, elm).checked)
					.map((elm) => Number(elm.dataset.index));

				const currentSubjects = $("#group-subjects-select").value;
				const membersListGmail = membersObj
					.getClass($("#group-class-select").value)
					.data.filter((student) =>
						membersListIndex.includes(student.index)
					)
					.map((student) => student.gmail);

				createGroupBtn.disabled = true;

				const groupBoxTypeInput = $("#group-box-type");

				if (!groupBoxTypeInput.value) {
					const createURL = `${host}/create`;
					const createOption = {
						method: "POST",

						headers: {
							"Content-Type": "application/json",
						},
						body: JSON.stringify({
							name: groupNameInput.value,
							start: startAt,
							duration: meetingDuration,
							members: membersListGmail,
							subjects: currentSubjects,
						}),
					};

					await fetch(createURL, createOption)
						.then((res) => res.json())
						.then((data) => {
							if (data.success) {
								this.addNewGroup({
									eventId: data.eventId,
									name: groupNameInput.value,
									class: groupClass,
									startAt,
									endAt,
									duration: meetingDuration,
									membersIndex: membersListIndex,
									subjects: currentSubjects,
									googleMeetLink: data.googleMeetLink,
								});

								attendanceObj.attendanceData.forEach(
									(studentInfo, index, arrayOrigin) => {
										if (
											membersListIndex.includes(
												studentInfo.index
											)
										) {
											arrayOrigin[index].workingGroupTimes.push(
												{
													eventId: data.eventId,
													startAt,
													endAt,
												}
											);
										}
									}
								);

								const introduceText = this.getIntroducetext(
									data.eventId
								);

								navigator.clipboard.writeText(introduceText);

								alert(
									"Tạo thành công!\nLink Google Meet của phòng học đã được copy vào bộ nhớ\n(chuột phải chọn paste hoặc tổ hợp Ctrl + V để dán)"
								);

								this.close();
							} else {
								alert("Tạo thất bại, vui lòng thử lại!");
							}
						});
				}

				if (groupBoxTypeInput.value) {
					const eventId = groupBoxTypeInput.value;

					const updateURL = `${host}/update`;
					const updateOption = {
						method: "PATCH",
						headers: {
							"Content-Type": "application/json",
						},
						body: JSON.stringify({
							eventId: groupBoxTypeInput.value,
							name: groupNameInput.value,
							start: startAt,
							duration: meetingDuration,
							members: membersListGmail,
							subjects: currentSubjects,
						}),
					};

					await fetch(updateURL, updateOption)
						.then((res) => res.json())
						.then((data) => {
							if (data.success) {
								// Delete group working time in old data
								const oldMembersListIndex =
									this.getGroup(eventId).membersIndex;

								attendanceObj.attendanceData.forEach(
									(studentInfo, index, arrayOrigin) => {
										if (
											oldMembersListIndex.includes(
												studentInfo.index
											)
										) {
											arrayOrigin[index].workingGroupTimes =
												arrayOrigin[
													index
												].workingGroupTimes.filter(
													(workingGroupTime) =>
														workingGroupTime.eventId !=
														eventId
												);
										}
									}
								);

								// Add group working time in new data
								attendanceObj.attendanceData.forEach(
									(studentInfo, index, arrayOrigin) => {
										if (
											membersListIndex.includes(
												studentInfo.index
											)
										) {
											arrayOrigin[index].workingGroupTimes.push(
												{
													eventId,
													startAt,
													endAt,
												}
											);
										}
									}
								);

								this.updateGroup(eventId, {
									name: groupNameInput.value,
									class: groupClass,
									startAt,
									endAt,
									duration: meetingDuration,
									membersIndex: membersListIndex,
									subjects: currentSubjects,
								});

								alert("Thông tin đã được cập nhật thành công!");

								this.close();
							}

							if (!data.success) {
								alert(
									"Cập nhật thông tin không thành công, vui lòng thử lại sau!"
								);
							}
						});
				}

				createGroupBtn.disabled = false;
			});
		},

		open() {
			const nowDate = new Date();

			// Set group type to "create"
			const groupTypeInput = $("#group-box-type");
			const headerTitleElm = $(
				"#create-group-box .create-group-box__box .box__header p"
			);
			const headerButtonElm = $(
				"#create-group-box .create-group-box__box .box__header .header__create-btn"
			);

			groupTypeInput.value = "";
			headerTitleElm.textContent = "Tạo nhóm mới";
			headerButtonElm.textContent = "Tạo";

			// Show create group box
			const inputStatus = $("#create-group-box-status");
			inputStatus.checked = true;

			// Set group name to blank
			const groupNameInput = $("#group-name-input");
			groupNameInput.value = "";

			// Render and select default group class
			const currentClassNameInfo = membersObj.getCurrentClassInfoName();
			const groupClassSelect = $("#group-class-select");
			const classList = membersObj.getAllClassInfo();

			groupClassSelect.innerHTML = `${classList
				.map(
					(classInfo) =>
						`<option value="${classInfo.classInfoName}">${classInfo.classInfoName}</option>`
				)
				.join("")}`;
			groupClassSelect.value = currentClassNameInfo;

			// Set start time to now
			const startMeetingTimeInput = $("#group-time-start-input");
			startMeetingTimeInput.value = `${nowDate.getFullYear()}-${
				`${nowDate.getMonth() + 1}`.length === 2
					? `${nowDate.getMonth() + 1}`
					: `0${nowDate.getMonth() + 1}`
			}-${
				`${nowDate.getDate()}`.length === 2
					? `${nowDate.getDate()}`
					: `0${nowDate.getDate()}`
			}T${
				`${nowDate.getHours()}`.length === 2
					? `${nowDate.getHours()}`
					: `0${nowDate.getHours()}`
			}:${
				`${nowDate.getMinutes()}`.length === 2
					? `${nowDate.getMinutes()}`
					: `0${nowDate.getMinutes()}`
			}`;

			// Set end time to first value
			const endMeetingTimeSelect = $(
				".group-info__group-end-time select"
			);
			endMeetingTimeSelect.value = $(
				"option",
				endMeetingTimeSelect
			).value;

			// Render members list
			this.renderMembersList();
		},

		openToChange(eventId) {
			const groupBoxTypeInput = $("#group-box-type");
			groupBoxTypeInput.value = eventId;

			const oldGroupInfo = this.getGroup(eventId);

			// Set group type to "change"
			const groupTypeInput = $("#group-box-type");
			const headerTitleElm = $(
				"#create-group-box .create-group-box__box .box__header p"
			);
			const headerButtonElm = $(
				"#create-group-box .create-group-box__box .box__header .header__create-btn"
			);

			groupTypeInput.value = eventId;
			headerTitleElm.textContent = "Chỉnh sửa thông tin";
			headerButtonElm.textContent = "Sửa";

			// Show create group box
			const inputStatus = $("#create-group-box-status");
			inputStatus.checked = true;

			// Set group name to blank
			const groupNameInput = $("#group-name-input");
			groupNameInput.value = oldGroupInfo.name;

			// Render and select default group class
			const groupClassSelect = $("#group-class-select");
			const classList = membersObj.getAllClassInfo();

			groupClassSelect.innerHTML = `${classList
				.map(
					(classInfo) =>
						`<option value="${classInfo.classInfoName}">${classInfo.classInfoName}</option>`
				)
				.join("")}`;
			groupClassSelect.value = oldGroupInfo.class;

			// Set start time to value saved
			const startMeetingTimeInput = $("#group-time-start-input");
			const oldStartMeetingTime = new Date(oldGroupInfo.startAt);
			oldStartMeetingTime.setMinutes(
				oldStartMeetingTime.getMinutes() -
					oldStartMeetingTime.getTimezoneOffset()
			);

			const oldStartMeetingTimeFullYears =
				oldStartMeetingTime.getFullYear();
			const oldStartMeetingTimeMonths =
				`${oldStartMeetingTime.getMonth() + 1}`.length < 2
					? `0${oldStartMeetingTime.getMonth() + 1}`
					: `${oldStartMeetingTime.getMonth() + 1}`;
			const oldStartMeetingTimeDates =
				`${oldStartMeetingTime.getDate()}`.length < 2
					? `0${oldStartMeetingTime.getDate()}`
					: `${oldStartMeetingTime.getDate()}`;
			const oldStartMeetingTimeHours =
				`${oldStartMeetingTime.getHours()}`.length < 2
					? `0${oldStartMeetingTime.getHours()}`
					: `${oldStartMeetingTime.getHours()}`;
			const oldStartMeetingTimeMinutes =
				`${oldStartMeetingTime.getMinutes()}`.length < 2
					? `0${oldStartMeetingTime.getMinutes()}`
					: `${oldStartMeetingTime.getMinutes()}`;

			startMeetingTimeInput.value = `${oldStartMeetingTimeFullYears}-${oldStartMeetingTimeMonths}-${oldStartMeetingTimeDates}T${oldStartMeetingTimeHours}:${oldStartMeetingTimeMinutes}`;

			// Set end time to first value
			const endMeetingTimeSelect = $(
				".group-info__group-end-time select"
			);

			endMeetingTimeSelect.value = oldGroupInfo.duration;

			// Render members list
			this.renderMembersList();

			// Check to checkbox student
			const membersSelected = oldGroupInfo.membersIndex;

			membersSelected.forEach((indexValue) => {
				const checkBoxInput = $(
					`#create-group-box .student-list-ctn__list .list__student[data-index="${indexValue}"] input`
				);

				checkBoxInput.checked = true;
			});
		},

		close() {
			const inputStatus = $("#create-group-box-status");
			inputStatus.checked = false;
		},

		renderMembersList(classNameInfo = $("#group-class-select").value) {
			const membersList = membersObj.getClass(classNameInfo).data;
			const membersListElm = $(
				"#create-group-box .body__student-list-ctn .student-list-ctn__list"
			);

			membersListElm.innerHTML = `${membersList
				.filter((student) =>
					generalMethods.validateEmail(student.gmail)
				)
				.map(
					(student) =>
						`
					<li class="list__student" data-index="${student.index}">
						<label>
							<span>${student.index} - ${student.name}</span>
							<div>
								<input type="checkbox" />
								<i class="fas fa-check"></i>
							</div>
						</label>
					</li>
					`
				)
				.join("")}`;
		},

		renderGroupListInSettingsBox() {
			const groupListElm = $(
				".settings-box__wrapper .tab-list__item.group .table__body"
			);
			const allGroupsInfo = this.getAllGroups();

			groupListElm.innerHTML = allGroupsInfo
				.map(
					(groupInfo) =>
						`<tr class="body__row" data-event-id="${
							groupInfo.eventId
						}">
							<td class="row__group-name">${groupInfo.name}</td>
							<td class="row__group-class">${groupInfo.class}</td>
							<td class="row__group-start">${(() => {
								const startAtLocalUTC = new Date(
									groupInfo.startAt
								);
								startAtLocalUTC.setMinutes(
									startAtLocalUTC.getMinutes() -
										startAtLocalUTC.getTimezoneOffset()
								);

								return startAtLocalUTC.toLocaleString("vn-VN", {
									timeZone: "Asia/Ho_Chi_Minh",
									hour12: false,
								});
							})()}</td>
							<td class="row__group-end">${(() => {
								const endAtLocalUTC = new Date(groupInfo.endAt);
								endAtLocalUTC.setMinutes(
									endAtLocalUTC.getMinutes() -
										endAtLocalUTC.getTimezoneOffset()
								);

								return endAtLocalUTC.toLocaleString("vn-VN", {
									timeZone: "Asia/Ho_Chi_Minh",
									hour12: false,
								});
							})()}</td>
							<td class="row__group-members">
								<div class="members-count">
									<i class="far fa-user"></i>
									<span>${groupInfo.membersIndex.length}</span>
									<i class="far fa-long-arrow-right"></i>
								</div>
							</td>
							<td class="row__group-meet-link">
								<a href="${
									groupInfo.googleMeetLink
								}" target="_blank" rel="noopener noreferrer">Truy cập phòng</a>
							</td>
							<td class="row__group-edit">
								<i class="fas fa-share"></i>
								<i class="fas fa-edit"></i>
								<i class="fas fa-trash"></i>
							</td>
						</tr>`
				)
				.join("");
		},

		initGroupStorage() {
			const currentData = localStorage.getItem(this.storageKey);

			if (currentData === null) {
				localStorage.setItem(this.storageKey, JSON.stringify([]));
			}
		},

		getAllGroups() {
			const currentData = JSON.parse(
				localStorage.getItem(this.storageKey)
			);

			return currentData;
		},

		setAllGroups(newData) {
			localStorage.setItem(this.storageKey, JSON.stringify(newData));
			this.renderGroupListInSettingsBox();
		},

		getGroup(eventId) {
			const currentData = this.getAllGroups();
			const event = currentData.find(
				(eventInfo) => eventInfo.eventId === eventId
			);

			if (!event) console.error("Không tìm thấy sự kiện này!");

			return event;
		},

		updateGroup(eventId, newGroupInfo) {
			const currentData = this.getAllGroups();
			const newData = currentData.map((groupInfo) =>
				groupInfo.eventId === eventId
					? { ...groupInfo, ...newGroupInfo }
					: groupInfo
			);

			this.setAllGroups(newData);
		},

		addNewGroup(groupsInfo) {
			const currentData = this.getAllGroups();
			currentData.push(groupsInfo);

			this.setAllGroups(currentData);
			this.renderGroupListInSettingsBox();
		},

		async deleteGroup(eventId) {
			const deleteUrl = `${host}/delete`;
			const deleteOption = {
				method: "DELETE",
				headers: {
					"Content-Type": "application/json",
				},
				body: JSON.stringify({ eventId }),
			};

			fetch(deleteUrl, deleteOption)
				.then((res) => res.json())
				.then((data) => {
					if (!data.success) {
						alert("XÓA THẤT BẠI, vui lòng thử lại sau!");
					}

					if (data.success) {
						let oldGroupData;
						const oldAllGroupData = this.getAllGroups();
						const newAllGroupData = oldAllGroupData.filter(
							(groupInfo) => {
								if (groupInfo.eventId != eventId) {
									return true;
								}

								if (groupInfo.eventId === eventId) {
									oldGroupData = groupInfo;

									return false;
								}
							}
						);

						// Set member working group time to default
						attendanceObj.attendanceData.forEach(
							(studentInfo, index, arrayOrigin) => {
								if (
									oldGroupData.membersIndex.includes(
										studentInfo.index
									)
								) {
									arrayOrigin[index].workingGroupTimes =
										arrayOrigin[index].workingGroupTimes.filter(
											(workingGroupTime) =>
												workingGroupTime.eventId !=
												oldGroupData.eventId
										);
								}
							}
						);

						this.setAllGroups(newAllGroupData);
						this.renderGroupListInSettingsBox();
					}
				});
		},

		getIntroducetext(eventId) {
			const groupInfo = this.getGroup(eventId);
			const introduceText = `Tên nhóm: ${groupInfo.name}\nLớp: ${
				groupInfo.class
			}\nBắt đầu: ${(() => {
				const startAt = new Date(groupInfo.startAt);
				startAt.setMinutes(
					startAt.getMinutes() - startAt.getTimezoneOffset()
				);

				return startAt.toLocaleString("vn-VN", {
					timeZone: "Asia/Ho_Chi_Minh",
					hour12: false,
				});
			})()}\nKết thúc: ${(() => {
				const endAt = new Date(groupInfo.endAt);
				endAt.setMinutes(
					endAt.getMinutes() - endAt.getTimezoneOffset()
				);

				return endAt.toLocaleString("vn-VN", {
					timeZone: "Asia/Ho_Chi_Minh",
					hour12: false,
				});
			})()}\nDS thành viên theo STT: ${groupInfo.membersIndex
				.map((indexValue, index) =>
					index === 0 ? `${indexValue}` : `, ${indexValue}`
				)
				.join("")}\nLink meet: ${
				groupInfo.googleMeetLink
			}\n===========================================`;

			return introduceText;
		},
	};

	taskBar = {
		initial() {
			// Taskbar left
			// Attendance button
			const taskBarLeft = $(".DAQYgc.xPh1xb.P9KVBf .p3Ljlc");
			const attendanceBtnElm = document.createElement("div");

			taskBarLeft.classList.add("taskbar__left");
			attendanceBtnElm.className = "left__attendance-state";

			attendanceBtnElm.innerHTML = `<input type="checkbox" id="attendance-state" /><div class="attendance-state__btn-wrapper"><label for="attendance-state" class="btn-wrapper__btn"><p class="btn__off-state">OFF</p><div class="btn__slide"></div><p class="btn__on-state">ON</p></label></div><div class="attendance-state__attendance-message"><span class="attendance-message__off-state"><p>Chưa bật điểm danh</p></span><span class="attendance-message__on-state"><p>12A12 - 00:00:00 (42/42)</p></span></div>`;

			const attendanceStateInput = $(
				"input#attendance-state",
				attendanceBtnElm
			);

			attendanceStateInput.addEventListener("change", (e) => {
				const value = e.target.checked;

				if (value) {
					attendanceObj.turnOn();
				} else {
					attendanceObj.turnOff();
				}
			});

			taskBarLeft.appendChild(attendanceBtnElm);

			// Taskbar center
			const taskbarCenter = $(".DAQYgc.xPh1xb.P9KVBf .rceXCe");
			const taskbarCenterChild = $(
				".DAQYgc.xPh1xb.P9KVBf .rceXCe .vqs9je"
			);
			const speakerBtn = document.createElement("label");

			taskbarCenter.classList.add("taskbar__center");

			speakerBtn.className = "center__speaker-btn";
			speakerBtn.innerHTML = `
				<input id="speaker-input" type="checkbox" checked />
				<i class="fas fa-volume-down"></i>
				<i class="fas fa-volume-mute"></i>
			`;

			taskbarCenterChild.prepend(speakerBtn);

			speakerObj.initial();

			// Taskbar right
			const taskBarRight = $(".DAQYgc.xPh1xb.P9KVBf .SGP0hd.kunNie");
			const newBtn = document.createElement("div");

			newBtn.innerHTML = `<div class="right__btn"><img src="${getLink(
				"img/settingsIcon.png"
			)}" alt="" class="btn__img"/></div>`;

			taskBarRight.classList.add("taskbar__right");
			taskBarRight.appendChild(newBtn);

			newBtn.addEventListener("click", classPageObj.settingsBox.open);
		},
	};

	settingsBox = {
		studentsSelectedIndex: [],

		initial() {
			const bodyElm = document.body;
			const settingsBox = document.createElement("div");

			const navigationListHtml = `
				<ul class="navigation__list">
					<li class="list__item active" data-index="0"> <i class="far fa-wrench"></i> <span class="item__label">Tính năng</span></li>
					<li class="list__item" data-index="1"> <i class="far fa-users-class"></i> <span class="item__label">Chia nhóm</span></li>
					<li class="list__item" data-index="2"> <i class="far fa-table"></i> <span class="item__label">Thống kê</span></li>
					<li class="list__item" data-index="3"> <i class="far fa-list-alt"></i> <span class="item__label">Danh sách HS</span></li>
					<li class="list__item" data-index="4"> <i class="far fa-history"></i>  <span class="item__label"> Lịch sử điểm danh </span></li>
					<li class="list__item" data-index="5"> <i class="far fa-sliders-h"></i> <span class="item__label">Cài đặt</span></li>
				</ul>	  
			`;
			const tabListContentFeaturesHtml = `<li class="tab-list__item features"> <div class="features__auto-turn-off-media"> <div class="auto-turn-off-media__content"> <h2 class="content__label"> Tự động tắt mic và camera </h2> <span class="content__desc"> Tắt mic và camera trong lúc đầu tham gia phòng học. </span> </div> <label class="toggle-btn"> <input type="checkbox" /> <div class="slider"></div> </label> </div> <div class="features__auto-accept"> <div class="auto-accept__content"> <h2 class="content__label"> Tự động duyệt thành viên </h2> <span class="content__desc"> Tự động duyệt những yêu cầu tham gia vào phòng học. </span> </div> <label class="toggle-btn"> <input type="checkbox" /> <div class="slider"></div> </label> </div> <div class="features__authenticate"> <div class="authenticate__content"> <h2 class="content__label"> Chặn yêu cầu bất hợp pháp </h2> <span class="content__desc"> Chặn những yêu cầu của cá nhân không nằm trong danh sách lớp. </span> </div> <label class="toggle-btn"> <input type="checkbox" /> <div class="slider"></div> </label> </div> <div class="features__auto-attendance"> <div class="auto-attendance__content"> <h2 class="content__label">Tự động điểm danh và lưu tin nhắn</h2> <span class="content__desc"> Điểm danh chi tiết các thành viên trong danh sách lớp học và lưu lại các tin nhắn trong lúc học.</span> </div> <label class="toggle-btn"> <input type="checkbox" /> <div class="slider"></div> </label> </div></li>`;
			const tabListContentStatisticalHtml = `
				<li class="tab-list__item statistical">
					<div class="statistical__state-message"><img src="${getLink(
						"img/toggleIcon.png"
					)}" alt=""/> <span>Bật điểm danh để bắt đầu thống kê!</span></div>
					<div class="statistical__slide-1">
						<div class="slide-1__class-info-name">
							<h2 class="class-info-name__class-name">...</h2>
							<span class="class-info-name__label">Lớp hiện tại</span>
						</div>
						<div class="slide-1__time-learning">
							<h2 class="time-learning__time">00:00:00</h2>
							<span class="time-learning__label">Thời gian</span>
						</div>
						<div class="slide-1__student-exist-count">
							<h2 class="student-exist-count__count">... HS</h2>
							<span class="student-exist-count__label">Học sinh có mặt</span>
						</div>
					</div>

					<div class="statistical__slide-2">
						<div class="slide-2__not-exist-student">
							<h2 class="not-exist-student__caption">HS hiện chưa có mặt</h2>
							<div class="not-exist-student__box"></div>
						</div>
					</div>

					<div class="statistical__slide-3">
						<h2 class="slide-3__caption">Thống kê chi tiết</h2>

						<div class="slide-3__note">
							<div class="note__head"><p>Chú thích</p></div>
							<div class="note__body">
								<span class="body__not-exist">
									<div class="circle circle--offline"></div>
									<p>Hiện không có mặt</p>
								</span>

								<span class="body__exist">
									<div class="circle circle--online"></div>
									<p>Hiện đang có mặt</p>
								</span>
								
								<span class="body__working-group">
									<div class="circle circle--working-group"></div>
									<p>Đang trong phòng họp nhóm</p>
								</span>
							</div>
						</div>

						<div class="slide-3__header">
							<div class="header__index">
									<span class="index__title">STT</span>
									<label class="index__sort" data-sort-type="0">
										<input type="radio" name="sort-column" value="index" checked />
										<i class="fas fa-sort-alpha-down"></i>
										<i class="fas fa-sort-alpha-down-alt"></i>	
									</label>
							</div>
							<div class="header__name"><span class="name__title">Họ và tên</span></div>
							<div class="header__exist-bar"><span class="exist-bar__title">Phần trăm có mặt</span></div>
							<div class="header__join-and-exit-timers"><span>Vào lần đầu</span></div>
							<div class="header__time-learning">
									<span class="time-learning__title">Thời gian</span>
									<label class="time-learning__sort" data-sort-type="0">
										<input type="radio" name="sort-column" value="timeLearning" />
										<i class="fas fa-sort-alpha-down"></i>
										<i class="fas fa-sort-alpha-down-alt"></i>
									</label>
							</div>
							<div class="header__not-exist-status">
								<span>Điểm danh</span>
							</div>
						</div>
						<ul class="slide-3__student-wrapper"></ul>
						<div class="slide-3__footer">
							<p>----- Hết danh sách -----</p>
						</div>
					</div>

					<div class="statistical__slide-4">
						<div class="slide-4__interactive-ctn">
							<header class="interactive-ctn__head">
								<p>Thống kê tương tác</p>
							</header>
			
							<div class="interactive-ctn__body">
								<ul class="body__interactive-list"></ul>
							</div>
						</div>
					</div>
				</li>
			`;

			const tabListContentGroupHtml = `
				<li id="group-tab" class="tab-list__item group">
					<div class="group__create-meeting-btn">
						<i class="fal fa-video-plus"></i>
						<p>Phòng nhóm mới</p>
					</div>

					<table class="group__table">
						<thead class="table__head">
							<tr class="head__row">
								<th class="row__group-name">Tên nhóm</th>
								<th class="row__group-class">Thuộc lớp</th>
								<th class="row__group-start">Bắt đầu</th>
								<th class="row__group-end">Kết thúc</th>
								<th class="row__group-members">Thành viên</th>
								<th class="row__group-meet-link">Meet Link</th>
								<th class="row__group-edit"></th>
							</tr>
						</thead>

						<tbody class="table__body"></tbody>
					</table>
				</li>
			`;

			const tabListContentStudentListHtml = `
				<li class="tab-list__item student-list">
					<div class="student-list__input-methods">
						<div class="input-methods__manual"><img src="${getLink(
							"img/keyboardIcon.png"
						)}" alt="" class="manual__icon" /> <span class="manual__title"> Nhập thủ công </span></div>
						<div class="input-methods__automatic"><img src="${getLink(
							"img/chatBotIcon.png"
						)}" alt="" class="automatic__icon" /> <span class="automatic__title"> Nhập tự động </span></div>
						<div class="input-methods__from-excel">
							<img src="${getLink(
								"img/tableIcon(2).png"
							)}" alt="" class="from-excel__icon" /><span class="from-excel__title"> Nhập bằng Excel </span></div>
					</div>

					<div class="student-list__add-student">
						<div class="add-student__img"><img src="${getLink(
							"img/addContactIcon.png"
						)}" alt="" /></div>
						<div class="add-student__input-range">
							<div class="input-range__input">
									<form>
										<div class="input__message-box">
											<img src="${getLink("img/warningIcon.png")}" alt="" />
											<p>Vui lòng nhập số thứ tự!</p>
										</div>
										<div class="input__index-ctn"><input type="text" class="index-ctn__input" placeholder=" " id="table-input-index" maxlength="4" /> <label for="table-input-index">STT</label></div>
										<div class="input__name-ctn"><input type="text" class="name-ctn__input" placeholder=" " id="table-input-name" /> <label for="table-input-name">Họ và tên</label></div>
										<div class="input__meet-name-ctn"><input type="text" class="meet-name-ctn__input" placeholder=" " id="table-input-meet-name" /> <label for="table-input-meet-name">Tên meet</label></div>
										<div class="input__gmail-ctn"><input type="text" class="gmail-ctn__input" placeholder=" " id="table-input-gmail" /> <label for="table-input-gmail">Địa chỉ Gmail</label></div>
										<div class="input__submit">
											<button class="submit__submit-btn" type="button"><p>Thêm</p></button>
										</div>
									</form>
							</div>
						</div>
					</div>

					<input type="checkbox" id="import-from-excel-state">
					<div class="student-list__import-from-excel">
						<h3>Hướng dẫn các bước nhập dữ liệu bằng Excel</h3>
						<div class="import-from-excel__step-1">
							<div class="step-1__number">1</div>
							<div class="step-1__content">
								<p>
									Tải file excel mẫu bằng tại <b><u><a href="https://drive.google.com/file/d/1knlakSeQX8uwTTw9ORwMUQN6e7tGJwYr/view?usp=sharing" target="_blank" rel="noopener noreferrer">ĐÂY</a></u></b> và điền thông tin học sinh (có thể cho bí thư hoặc lớp trưởng làm).
								</p>
							</div>
						</div>
						<div class="import-from-excel__step-2">
							<div class="step-2__number">2</div>
							<div class="step-2__content">
								<p>
									Sau khi điền xong file excel hãy nhấn vào nút này để nhập: <input type="file" id="student-list-excel-file-input" accept="msexcel/*" />
								</p>
							</div>
						</div>
						<div class="import-from-excel__step-3">
							<div class="step-3__number">3</div>
							<div class="step-3__content">
								<p>
									Nhập xong file excel hãy nhấn nút này để hoàn tất <button id="student-list-excel-file-submit-btn" disabled>Cập nhật bằng file này</button>
								</p>
							</div>
						</div>
					</div>

					<div class="student-list__table">
						<table class="table__student-table" cellspacing="0" cellpadding="0">
							<thead class="student-table__header">
								<tr class="header__caption">
									<td class="caption__content" colspan="6">Danh sách học sinh</td>
								</tr>
								<tr class="header__tools-bar">
									<td class="tools-bar__wrapper" colspan="6">
										<div class="wrapper__bar">
												<div class="bar__left-slide">
													<span class="left-slide__select-all"> <p>Chọn tất cả</p> </span> <span class="left-slide__unselect-all"> <p>Bỏ chọn</p> </span> <span class="left-slide__selected-count">đã chọn 0</span>
												</div>
												<div class="bar__right-slide">
													<div><div class="right-slide__undo"><img src="${getLink(
														"img/undoIcon.png"
													)}" alt="" /></div></div>
													<div><div class="right-slide__redo"><img src="${getLink(
														"img/redoIcon.png"
													)}" alt="" /></div></div>
													<div><div class="right-slide__delete"><img src="${getLink(
														"img/deleteIcon.png"
													)}" alt="" /></div></div>
												</div>
										</div>
									</td>
								</tr>
								<tr class="header__class-list">
									<td class="class-list__wrapper" colspan="6">
										<div class="wrapper__bar">
												<div class="bar__left-slide"><ul class="left-slide__class-list"></ul></div>
												<div class="bar__right-slide">
													<button class="right-slide__add-class-btn">
														<img src="${getLink("img/addIcon.png")}" alt="" />
														<p>Thêm lớp</p>
													</button>
												</div>
										</div>
									</td>
								</tr>
								<tr class="header__row">
									<th class="row__index">STT</th>
									<th class="row__name">Họ và tên</th>
									<th class="row__meet-name">Tên Google meet</th>
									<th class="row__gmail">Địa chỉ Gmail</th>
									<th class="row__exist-state">Trạng thái</th>
									<th class="row__select">✔</th>
								</tr>
							</thead>
							<tbody class="student-table__body"></tbody>
							<tfoot class="student-table__foot">
									<tr>
										<td colspan="6"></td>
									</tr>
							</tfoot>
						</table>
					</div>
				</li>
			`;
			const tabListContentHistoryHtml = `<li class="tab-list__item attendance-history"> <ul class="attendance-history__wrapper"></ul></li>`;
			const tabListContentSettingsHtml = `<li class="tab-list__item settings"> <ul class="settings__list-settings"> <li class="list-settings__percent-mark"> <div class="percent-mark__content"> <h2 class="content__label">Đánh dấu khi tỷ lệ có mặt dưới</h2> <p class="content__desc">Nếu thành viên nào có mặt dưới phần trăm quy định sẽ được đánh dấu lại và tô đậm</p> </div> <div class="percent-mark__input"> <input type="number" min="1" max="100" value="${
				settingsObj.getSettings().timingExistPercent
			}" /> </div> </li> </ul></li>`;

			settingsBox.className = "settings-box__wrapper";
			settingsBox.innerHTML = `<div class="wrapper__box"> <div class="box__header"><span class="header__title">Tính năng</span> <img src="${getLink(
				"img/closeIcon.png"
			)}" alt="" class="header__close-btn" /></div> <div class="box__body"> <div class="body__navigation">${navigationListHtml}</div> <div class="body__content"> <ul class="content__tab-list"> ${tabListContentFeaturesHtml} ${tabListContentGroupHtml} ${tabListContentStatisticalHtml} ${tabListContentStudentListHtml} ${tabListContentHistoryHtml} ${tabListContentSettingsHtml} </ul> </div> </div></div>`;

			bodyElm.appendChild(settingsBox);
			this.renderClassList();
			this.renderStudentList();
			this.resetStyleToolsbarBtnStudentList();
			this.renderAttendanceHistoryList();
			this.intervalHandle();
			this.initEvent();

			// Set event handlers for settingsBox
			function setEventHandlers() {
				// FOR SETTINGS BOX
				const closeBtn = $(
					".settings-box__wrapper .wrapper__box .box__header .header__close-btn"
				);
				closeBtn.addEventListener("click", this.close);

				const indexSortWrapper = $(
					".tab-list__item.statistical .slide-3__header .index__sort",
					settingsBox
				);
				const timeLearningSortWrapper = $(
					".tab-list__item.statistical .slide-3__header .time-learning__sort",
					settingsBox
				);

				indexSortWrapper.addEventListener(
					"click",
					sortWrapperClickHandle
				);
				timeLearningSortWrapper.addEventListener(
					"click",
					sortWrapperClickHandle
				);

				function sortWrapperClickHandle(e) {
					// UI Style
					e.preventDefault();

					let currentElm = e.target;

					while (currentElm.tagName != "LABEL") {
						currentElm = currentElm.parentNode;
					}

					const inputSort = $(`input[type="radio"]`, currentElm);
					const allSortWrapper = Array.from(
						$$(".tab-list__item.statistical .slide-3__header label")
					);

					allSortWrapper
						.filter((labelElm) => {
							const inputSortInCurrentLabel = $(
								`input[type="radio"]`,
								labelElm
							);

							return !(inputSort === inputSortInCurrentLabel);
						})
						.forEach((labelElm) => {
							labelElm.dataset.sortType = 0;
						});

					if (!inputSort.checked) {
						inputSort.checked = !inputSort.checked;
					} else {
						currentElm.dataset.sortType =
							currentElm.dataset.sortType == 0 ? 1 : 0;
					}

					// Handle reRender to sort
				}

				// CREATE GROUP TAB
				const createNewGroupBtn = $(
					"#group-tab .group__create-meeting-btn"
				);
				createNewGroupBtn.addEventListener("click", (e) => {
					classPageObj.createGroupBox.open();
				});

				// STATISTICAL TAB SLIDE 4
				const interactiveCtn = $(
					".tab-list__item.statistical .statistical__slide-4 .slide-4__interactive-ctn"
				);
				interactiveCtn.addEventListener("click", (e) => {
					let target = e.target;

					while (
						!target.className
							.split(" ")
							.includes("info-ctn__comment") ||
						target.className
							.split(" ")
							.includes("slide-4__interactive-ctn")
					) {
						target = target.parentNode;
					}

					const cmtBoxElm = $(".cmt-box-wrapper");
					const headerNameElm = $(
						".box__header p:last-child",
						cmtBoxElm
					);
					const cmtListElm = $(".body__cmt-list", cmtBoxElm);
					const chatsData = JSON.parse($("p", target).textContent);
					let cmtItemsHtml = "";

					headerNameElm.textContent = target.dataset.name;
					chatsData.forEach((chat) => {
						const time = chat.time;

						cmtItemsHtml += chat.contents
							.map(
								(content, index, originArr) =>
									`<li class="cmt-list__cmt ${
										index === 0 ? "first" : ""
									} ${
										index === originArr.length - 1 ? "last" : ""
									}">
										<span>${content}</span>
										<time>${time}</time>
									</li>`
							)
							.join("");
					});

					cmtListElm.innerHTML = cmtItemsHtml;
					cmtBoxElm.classList.add("show");
				});

				// FOR STUDENT LIST TAB
				const manualInputMethod = $(
					".settings-box__wrapper .tab-list__item.student-list .input-methods__manual"
				);
				const automaticInputMethod = $(
					".settings-box__wrapper .tab-list__item.student-list .input-methods__automatic"
				);

				manualInputMethod.addEventListener("click", (e) => {
					if (!this.addStudentBox.existState) {
						this.addStudentBox.open();
					} else {
						this.addStudentBox.close();
					}
				});
				this.addStudentBox.initial();

				automaticInputMethod.addEventListener("click", (e) => {
					if (settingsObj.getSettings().autoAttendance)
						return alert(
							"Vui lòng tắt điểm danh tự động trước khi sửa thông tin học sinh!"
						);

					let allExistMembersName = [...$$(".KsCJ0 .kvLJWc .ZjFb7c")]
						.map((elm) => elm.textContent)
						.filter(
							(memberName, index, thisArray) =>
								thisArray.indexOf(memberName) === index
						);
					let allClassInfo = membersObj.getAllClassInfo();

					let allExistMembersHasIndexInfo = allExistMembersName
						.filter((memberName) => parseInt(memberName))
						.map((memberName) => ({
							index: parseInt(memberName),
							name:
								memberName?.split(".")[1]?.split("-")[0].trim() ||
								memberName,
							meetName: memberName,
							gmail: "Chưa nhập",
						}));
					const allExistMembersHasIndexIndex =
						allExistMembersHasIndexInfo.map(
							(member) => member.index
						);
					const allExistMembersNotHasIndexInfo = allExistMembersName
						.filter((memberName) => !parseInt(memberName))
						.map((memberName) => ({
							name:
								memberName?.split(".")[1]?.split("-")[0].trim() ||
								memberName,
							meetName: memberName,
							gmail: "Chưa nhập",
						}));

					// move duplicate index member to "allExistMembersNotHasIndexInfo"
					allExistMembersHasIndexInfo =
						allExistMembersHasIndexInfo.filter((member, index) => {
							if (
								allExistMembersHasIndexIndex.indexOf(
									member.index
								) === index
							) {
								return true;
							} else {
								allExistMembersNotHasIndexInfo.push(member);
								return false;
							}
						});

					// Merge 2 list
					// ("allExistMembersHasIndexInfo", "allExistMembersNotHasIndexInfo")
					// to render
					const membersHasIndexIndex =
						allExistMembersHasIndexInfo.map(
							(member) => member.index
						);
					let maxIndex = Math.max(...membersHasIndexIndex);
					maxIndex = maxIndex === -Infinity ? 0 : maxIndex;

					const members = [...allExistMembersHasIndexInfo];

					while (allExistMembersNotHasIndexInfo.length > 0) {
						const currentNotHasIndexMember =
							allExistMembersNotHasIndexInfo.shift();
						members.push({
							...currentNotHasIndexMember,
							index: maxIndex + 1,
						});
						maxIndex++;
					}

					classPageObj.undoAndRedoMembersList.addHistory(
						membersObj.getCurrentClassInfoName(),
						allClassInfo.map((classInfo) =>
							classInfo.classInfoName ===
							membersObj.getCurrentClassInfoName()
								? {
										classInfoName:
											membersObj.getCurrentClassInfoName(),
										data: members,
								  }
								: classInfo
						)
					);
				});

				// excelInputMethod.addEventListener("change", (e) => {
				// 	const reader = new FileReader();

				// 	reader.readAsArrayBuffer(e.target.files[0]);

				// 	reader.onload = (e) => {
				// 		const bufferData = e.target.result;
				// 		const workBook = XLSX.read(bufferData, {
				// 			type: "buffer",
				// 		});

				// 		console.log(
				// 			workBook.Sheets[`${workBook.SheetNames[0]}`]
				// 		);
				// 	};
				// });

				//
				// For table header toolsbar student list
				//
				const selectAllBtn = $(
					".settings-box__wrapper .student-list__table .left-slide__select-all"
				);
				const unSelectAllBtn = $(
					".settings-box__wrapper .student-list__table .left-slide__unselect-all"
				);
				const undoBtn = $(
					".settings-box__wrapper .student-list__table .right-slide__undo"
				);
				const redoBtn = $(
					".settings-box__wrapper .student-list__table .right-slide__redo"
				);
				const deleteBtn = $(
					".settings-box__wrapper .student-list__table .right-slide__delete"
				);

				selectAllBtn.addEventListener("click", (e) => {
					const inputsNotSelect = [
						...$$(
							".body__row .row__select input:not(:checked)",
							settingsBox
						),
					];
					inputsNotSelect.forEach((selectInput) => {
						selectInput.checked = true;
					});
					this.studentsSelectedIndex = [
						...membersObj
							.getClass()
							.data.map((student) => student.index),
					];
					this.resetStyleToolsbarBtnStudentList();
				});
				unSelectAllBtn.addEventListener("click", (e) => {
					const inputSelected = [
						...$$(
							".body__row .row__select input:checked",
							settingsBox
						),
					];
					inputSelected.forEach((selectInput) => {
						selectInput.checked = false;
					});
					this.studentsSelectedIndex = [];
					this.resetStyleToolsbarBtnStudentList();
				});
				undoBtn.addEventListener("click", () => {
					if (settingsObj.getSettings().autoAttendance)
						return alert(
							"Vui lòng tắt điểm danh tự động trước khi sửa thông tin học sinh!"
						);

					classPageObj.undoAndRedoMembersList.undo();
				});
				redoBtn.addEventListener("click", () => {
					if (settingsObj.getSettings().autoAttendance)
						return alert(
							"Vui lòng tắt điểm danh tự động trước khi sửa thông tin học sinh!"
						);

					classPageObj.undoAndRedoMembersList.redo();
				});
				deleteBtn.addEventListener("click", (e) => {
					if (settingsObj.getSettings().autoAttendance)
						return alert(
							"Vui lòng tắt điểm danh tự động trước khi sửa thông tin học sinh!"
						);

					let newMembers = [];
					let allClassInfo = membersObj.getAllClassInfo();
					const classInfo = membersObj.getClass();
					const allInputChecked = [
						...$$(
							".settings-box__wrapper .body__row .row__select input:checked"
						),
					];
					const studentsIndexDelete = allInputChecked.map((input) =>
						Number(
							input.parentNode.parentNode.parentNode.dataset
								.studentIndex
						)
					);

					if (allInputChecked.length === 0) return;

					newMembers = classInfo.data.filter(
						(member) => !studentsIndexDelete.includes(member.index)
					);

					classPageObj.undoAndRedoMembersList.addHistory(
						membersObj.getCurrentClassInfoName(),
						allClassInfo.map((classInfo) =>
							classInfo.classInfoName ===
							membersObj.getCurrentClassInfoName()
								? {
										classInfoName:
											membersObj.getCurrentClassInfoName(),
										data: newMembers,
								  }
								: classInfo
						)
					);
				});

				//
				// For class list infomation
				//
				const addClassBtn = $(
					".tab-list__item.student-list .student-table__header .header__class-list .right-slide__add-class-btn",
					settingsBox
				);

				// handle add class info
				addClassBtn.addEventListener(
					"click",
					handleAddClass.bind(this)
				);

				function handleAddClass(e) {
					const classInfoName = prompt(
						"Danh sách lớp sẽ được tạo bằng danh sách hiện tại được hiển thị! \n\n" +
							"Vui lòng nhập tên lớp để thêm. VD: 12A12,..."
					);

					if (classInfoName === null) return;

					if (!classInfoName) {
						const repeatInput = confirm(
							"\n\nTên lớp không thể để trống!\n\n" +
								"Bạn có muốn nhập lại không?"
						);

						if (repeatInput) return handleAddClass(e);
					} else {
						const allClassNameInfo = membersObj.getAllClassName();
						if (allClassNameInfo.includes(classInfoName)) {
							const repeatInput = confirm(
								"\n\n\n\nTên của lớp học này đã tồn tại!\nBạn có muốn nhập lại không? "
							);
							if (repeatInput) handleAddClass(e);

							return;
						}

						const newClassInfo = membersObj.getClass();

						newClassInfo.classInfoName = classInfoName;
						classPageObj.undoAndRedoMembersList.addHistory(
							classInfoName,
							[...membersObj.getAllClassInfo(), newClassInfo]
						);

						this.renderClassList();
						this.renderStudentList();
					}
				}

				// FOR STUDENT LIST TABLE
				const studentListTableBodyElm = $(
					".settings-box__wrapper .tab-list__item.student-list .student-table__body"
				);

				studentListTableBodyElm.addEventListener("click", (e) => {
					const tableRow = (() => {
						let currentTarget = e.target;

						while (!currentTarget.className.includes("body__row")) {
							currentTarget = currentTarget.parentNode;
						}

						return currentTarget;
					})();

					const studentIndex = Number(tableRow.dataset.studentIndex);
					const rowAllInput = [...$$("input", tableRow)];
					const inputSelect = rowAllInput.at(-1);

					// Handle click table row
					if (e.target.tagName != "INPUT") {
						inputSelect.checked = !inputSelect.checked;

						if (inputSelect.checked) {
							this.studentsSelectedIndex.push(studentIndex);
						} else {
							for (
								let index = 0;
								index < this.studentsSelectedIndex.length;
								index++
							) {
								if (
									this.studentsSelectedIndex[index] ===
									studentIndex
								) {
									this.studentsSelectedIndex.splice(index, 1);
									break;
								}
							}
						}

						const selectedCountElm = $(
							".settings-box__wrapper .student-list__table .left-slide__selected-count"
						);

						this.resetStyleToolsbarBtnStudentList();
						selectedCountElm.textContent = `đã chọn ${this.studentsSelectedIndex.length}`;
					}

					switch (e.target.className) {
						case "body__row":
							break;
					}
				});
				studentListTableBodyElm.addEventListener("change", (e) => {
					const tableRow = (() => {
						let currentTarget = e.target;

						while (!currentTarget.className.includes("body__row")) {
							currentTarget = currentTarget.parentNode;
						}

						return currentTarget;
					})();

					switch (e.target.parentNode.className) {
						case "row__index":
							handleChangeIndex.call(this);
							break;

						case "row__name":
							handleChangeNameAndMeetName.call(
								this,
								"name",
								"Bạn chưa nhập trường Họ và tên!\n\nBạn có muốn nhập lại không?"
							);
							break;

						case "row__meet-name":
							handleChangeNameAndMeetName.call(
								this,
								"meetName",
								"Bạn chưa nhập trường Tên meet!\n\nBạn có muốn nhập lại không?"
							);
							break;

						case "row__gmail":
							handleChangeGmail.call(this);
					}

					function handleChangeIndex() {
						if (settingsObj.getSettings().autoAttendance) {
							e.target.value = tableRow.dataset.studentIndex;

							return alert(
								"Vui lòng tắt điểm danh tự động trước khi sửa thông tin học sinh!"
							);
						}

						const oldIndex = Number(tableRow.dataset.studentIndex);
						const indexValue = e.target.value;
						const studentsClassInfoData = membersObj.getClass().data;
						const studentOldArrIndex =
							studentsClassInfoData.findIndex(
								(student) => student.index === oldIndex
							);
						const studentNewArrIndex =
							studentsClassInfoData.findIndex(
								(student) => student.index === Number(indexValue)
							);

						// Value check invalid
						function checkValue() {
							const valueArr = indexValue.split("");

							// Empty
							if (valueArr.length === 0) return false;

							// Symbol error
							const symbolError = valueArr.some((symbol) =>
								isNaN(Number(symbol))
							);
							if (symbolError) return false;

							return true;
						}
						if (!checkValue.call(this)) {
							e.target.value = oldIndex;
							return;
						}

						// when index was used handle
						function indexIsUsedCheck() {
							const studentUsedIndex = studentsClassInfoData.find(
								(studentInfo) =>
									studentInfo.index === Number(indexValue)
							);

							if (studentUsedIndex?.name) {
								const replaceCofirm = confirm(
									`Số thứ tự này đã được sử dụng bởi ${studentUsedIndex.name}!\n\nBạn có muốn GHI ĐÈ lên không?`
								);

								if (replaceCofirm) {
									studentsClassInfoData[studentOldArrIndex] = {
										...studentsClassInfoData[studentOldArrIndex],
										index: Number(indexValue),
									};

									studentsClassInfoData.splice(
										studentNewArrIndex,
										1
									);

									this.studentsSelectedIndex =
										this.studentsSelectedIndex.filter(
											(index) => index != oldIndex
										);

									classPageObj.undoAndRedoMembersList.addHistory(
										membersObj.getCurrentClassInfoName(),
										membersObj
											.getAllClassInfo()
											.map((classInfo) =>
												classInfo.classInfoName ===
												membersObj.getCurrentClassInfoName()
													? {
															classInfoName:
																membersObj.getCurrentClassInfoName(),
															data: studentsClassInfoData,
													  }
													: classInfo
											)
									);
								}

								return false;
							}

							return true;
						}
						if (!indexIsUsedCheck.call(this)) {
							e.target.value = oldIndex;
							return;
						}

						// Don't change handle
						if (oldIndex === indexValue) return;

						studentsClassInfoData[studentOldArrIndex] = {
							...studentsClassInfoData[studentOldArrIndex],
							index: Number(indexValue),
						};

						this.studentsSelectedIndex.push(indexValue);
						classPageObj.undoAndRedoMembersList.addHistory(
							membersObj.getCurrentClassInfoName(),
							membersObj.getAllClassInfo().map((classInfo) =>
								classInfo.classInfoName ===
								membersObj.getCurrentClassInfoName()
									? {
											classInfoName:
												membersObj.getCurrentClassInfoName(),
											data: studentsClassInfoData,
									  }
									: classInfo
							)
						);
					}

					function handleChangeNameAndMeetName(
						checkMode,
						errorMessage
					) {
						let originNameValue = membersObj
							.getClass(membersObj.getCurrentClassInfoName())
							.data.find(
								(member) =>
									member.index ===
									Number(tableRow.dataset.studentIndex)
							);
						originNameValue =
							checkMode === "name"
								? originNameValue.name
								: originNameValue.meetName;

						if (settingsObj.getSettings().autoAttendance) {
							e.target.value = originNameValue || "error!";

							return alert(
								"Vui lòng tắt điểm danh tự động trước khi sửa thông tin học sinh!"
							);
						}

						const inputValue = e.target.value;
						const studentsClassInfoData = membersObj.getClass().data;
						const studentIndex = studentsClassInfoData.findIndex(
							(student) =>
								student.index ===
								Number(tableRow.dataset.studentIndex)
						);

						function valueCheck() {
							if (inputValue.length === 0) {
								const repeatFillConfirm = confirm(errorMessage);

								if (repeatFillConfirm) e.target.focus();
								e.target.value = originNameValue;
								return false;
							}

							return true;
						}
						if (!valueCheck.call(this)) return;

						if (checkMode === "name") {
							studentsClassInfoData[studentIndex].name = inputValue;
						} else {
							studentsClassInfoData[studentIndex].meetName =
								inputValue;
						}

						classPageObj.undoAndRedoMembersList.addHistory(
							membersObj.getCurrentClassInfoName(),
							membersObj.getAllClassInfo().map((classInfo) =>
								classInfo.classInfoName ===
								membersObj.getCurrentClassInfoName()
									? {
											classInfoName:
												membersObj.getCurrentClassInfoName(),
											data: studentsClassInfoData,
									  }
									: classInfo
							)
						);
					}

					function handleChangeGmail() {
						const gmailInputValue = e.target.value;
						const newClassInfo = membersObj.getClass();

						newClassInfo.data.forEach(
							(student, index, arrayOrigin) => {
								if (
									student.index ===
									Number(tableRow.dataset.studentIndex)
								) {
									arrayOrigin[index] = {
										...student,
										gmail: gmailInputValue,
									};
								}
							}
						);

						classPageObj.undoAndRedoMembersList.addHistory(
							membersObj.getCurrentClassInfoName(),
							membersObj
								.getAllClassInfo()
								.map((classInfo) =>
									classInfo.classInfoName ===
									membersObj.getCurrentClassInfoName()
										? newClassInfo
										: classInfo
								)
						);
					}
				});

				// FOR HISTORY ATTENDANCE INFO
				const attendanceHistoryWrapperElm = $(
					".settings-box__wrapper .tab-list__item.attendance-history .attendance-history__wrapper"
				);

				attendanceHistoryWrapperElm.addEventListener("click", (e) => {
					if (e.target.className === "attendance-history__wrapper")
						return;

					let historyAttendanceItem = e.target;
					let classNameChain = [];
					let currentNode = e.target;

					while (
						!historyAttendanceItem.className.includes(
							"wrapper__item"
						)
					) {
						historyAttendanceItem = historyAttendanceItem.parentNode;
					}
					while (
						!classNameChain.includes("wrapper__item") &&
						currentNode.className != "attendance-history__wrapper"
					) {
						classNameChain.push(currentNode.className);
						currentNode = currentNode.parentNode;
					}

					const attendanceHistoryData =
						attendanceHistoryObj.getHistory()[
							Number(historyAttendanceItem.dataset.index)
						];

					if (classNameChain.includes("right-slide__to-excel-btn")) {
						return attendanceHistoryObj.renderExcel(
							attendanceHistoryData
						);
					}

					if (classNameChain.includes("right-slide__to-pdf-btn")) {
						return attendanceHistoryObj.renderPdf(
							attendanceHistoryData
						);
					}

					if (classNameChain.includes("right-slide__delete-btn")) {
						const deleteConfirm = confirm(
							"Bạn có chắc chắn muốn XÓA nội dung điểm danh này không?"
						);

						if (deleteConfirm)
							attendanceHistoryObj.deleteHistory(
								Number(historyAttendanceItem.dataset.index)
							);

						return;
					}

					attendanceHistoryObj.renderAttendancePage(
						attendanceHistoryData
					);
				});

				// FOR SETTINGS TAB
				const existPercentInputElm = $(
					".tab-list__item.settings .percent-mark__input input",
					settingsBox
				);

				existPercentInputElm.addEventListener("change", (e) => {
					if (!e.target.value.length) {
						const confirmInput = confirm(
							"Bạn chưa nhập dữ liệu!\n\nBạn có muốn nhập lại không?"
						);

						e.target.value =
							settingsObj.getSettings().timingExistPercent;

						if (confirmInput) return e.target.focus();
					}

					if (
						Number(e.target.value) < 1 ||
						Number(e.target.value) > 100
					) {
						const confirmInput = confirm(
							"Trường này chỉ cho phép các số từ 1-100!\n\nBạn có muốn nhập lại không?"
						);
						e.target.value =
							settingsObj.getSettings().timingExistPercent;

						if (confirmInput) return e.target.focus();
					}

					settingsObj.setSettings({
						timingExistPercent: Number(e.target.value),
					});
				});
			}
			setEventHandlers.call(this);

			// Set handle navigation click
			function setHandleNavigationClick() {
				const navigationItems = $$(
					".settings-box__wrapper .navigation__list .list__item"
				);
				navigationItems.forEach((item) => {
					item.addEventListener("click", navigationItemClickHandler);

					function navigationItemClickHandler(e) {
						const itemIndex = Number(item.dataset.index);
						const translateY = Math.trunc(100 * itemIndex);
						const tabListSlider = $(".content__tab-list");
						const currentActiveNavigationItem = $(
							".list__item.active"
						);
						const settingsBoxTitleElm = $(
							".settings-box__wrapper .header__title"
						);

						tabListSlider.style.transform = `translateY(-${translateY}%)`;
						currentActiveNavigationItem.classList.remove("active");
						item.classList.add("active");
						settingsBoxTitleElm.textContent = $(
							".item__label",
							item
						).textContent;
					}
				});
			}
			setHandleNavigationClick.call(this);

			// Setup status features with LocalStorage
			function setupStatusFeatures() {
				const settings = settingsObj.getSettings();
				const autoTurnOffMediaInput = $(
					".settings-box__wrapper .tab-list__item.features .features__auto-turn-off-media .toggle-btn input"
				);
				const autoAcceptInput = $(
					".settings-box__wrapper .tab-list__item.features .features__auto-accept .toggle-btn input"
				);
				const blockAccessInvalidInput = $(
					".settings-box__wrapper .tab-list__item.features .features__authenticate .toggle-btn input"
				);
				const autoAttendanceInput = $(
					".settings-box__wrapper .tab-list__item.features .features__auto-attendance .toggle-btn input"
				);

				this.settingsBoxFeaturesResetStyle();

				autoTurnOffMediaInput.addEventListener("change", (e) => {
					const settings = settingsObj.getSettings();
					const newSettings = {
						...settings,
						autoTurnOffMedia: e.target.checked,
					};

					settingsObj.setSettings(newSettings);
				});

				if (settings.autoAccept)
					classPageObj.autoAcceptHandler.turnOn();
				autoAcceptInput.addEventListener("change", (e) => {
					const settings = settingsObj.getSettings();
					const newSettings = {
						...settings,
						autoAccept: e.target.checked,
					};

					settingsObj.setSettings(newSettings);

					if (e.target.checked)
						classPageObj.autoAcceptHandler.turnOn();
					else classPageObj.autoAcceptHandler.turnOff();
				});

				blockAccessInvalidInput.addEventListener("change", (e) => {
					const settings = settingsObj.getSettings();
					const newSettings = {
						...settings,
						blockAccessInvalid: e.target.checked,
					};

					settingsObj.setSettings(newSettings);
				});

				if (settings.autoAttendance) attendanceObj.turnOn();
				autoAttendanceInput.addEventListener("change", (e) => {
					if (e.target.checked) attendanceObj.turnOn();
					else attendanceObj.turnOff();
				});
			}
			setupStatusFeatures.call(this);
		},

		initEvent() {
			// Set event input methods icon click
			const importFormExcelInput = $("#student-list-excel-file-input");
			const importFromExcelInputState = $("#import-from-excel-state");
			const importFromExcelIcon = $(
				".settings-box__wrapper .tab-list__item.student-list .student-list__input-methods .input-methods__from-excel"
			);
			const importFormExcelSubmitBtn = $(
				"#student-list-excel-file-submit-btn"
			);

			importFromExcelIcon.addEventListener("click", (e) => {
				importFromExcelInputState.checked =
					!importFromExcelInputState.checked;
			});

			importFormExcelInput.addEventListener("change", (e) => {
				const inputFile = e.target.files[0];

				if (!inputFile) {
					importFormExcelSubmitBtn.disabled = true;

					return;
				}

				const fileFormat = inputFile.name.split(".").pop();
				const excelFileFormats = [
					"xlsx",
					"xlsm",
					"xlsb",
					"xltx",
					"xltm",
					"xls",
					"xlt",
				];

				if (!excelFileFormats.includes(fileFormat)) {
					e.target.value = "";
					importFormExcelSubmitBtn.disabled = true;
					alert("Vui lòng chỉ chọn file Excel!");

					return;
				}

				importFormExcelSubmitBtn.disabled = false;
			});

			importFormExcelSubmitBtn.addEventListener("click", (e) => {
				const inputFile = importFormExcelInput.files[0];

				// Update date and render handle
				readXlsxFile(inputFile).then((excelData) => {
					const classNameInfo = excelData.shift()[1];
					excelData.shift();

					let membersInfoFromExcel = excelData.map((rowData) => ({
						index: rowData[0] || 0,
						name: rowData[1] || "",
						group: rowData[2] || 0,
						meetName: rowData[3] || "",
						gmail: rowData[4] || "",
					}));

					// Sort mebersInfoFromExcel by index value
					membersInfoFromExcel.sortObject("index", 0);

					// Delete invalid members info
					membersInfoFromExcel = membersInfoFromExcel.filter(
						(memberInfo) => memberInfo.meetName
					);

					// Optimize members info
					membersInfoFromExcel = membersInfoFromExcel.map(
						(memberInfo) => ({
							...memberInfo,
							name: memberInfo.name
								? memberInfo.name
								: memberInfo.meetName,
						})
					);

					// Get the valid index members
					let minIndex = 1;

					membersInfoFromExcel = membersInfoFromExcel.map(
						(studentInfo) => {
							if (studentInfo.index === minIndex) {
								minIndex++;

								return studentInfo;
							}

							if (studentInfo.index != minIndex) {
								studentInfo.index = null;

								return studentInfo;
							}
						}
					);

					// Handle the invalid index member
					let membersInfoInvalid = [];
					membersInfoFromExcel = membersInfoFromExcel.filter(
						(studentInfo) => {
							if (studentInfo.index === null) {
								membersInfoInvalid.push(studentInfo);
								return false;
							}

							if (studentInfo.index !== null) {
								return true;
							}
						}
					);

					console.log(membersInfoInvalid);

					membersInfoInvalid = membersInfoInvalid.map(
						(studentInfo) => {
							studentInfo.index = minIndex;
							minIndex++;

							return studentInfo;
						}
					);

					// Merge invalid and valid member array
					membersInfoFromExcel = [
						...membersInfoFromExcel,
						...membersInfoInvalid,
					];
					membersInfoFromExcel.sortObject("index", 0);

					const currentClassInfoName =
						membersObj.getCurrentClassInfoName();
					const allClassInfo = membersObj.getAllClassInfo();

					classPageObj.undoAndRedoMembersList.addHistory(
						currentClassInfoName,
						allClassInfo.map((classInfo) =>
							classInfo.classInfoName === currentClassInfoName
								? {
										classInfoName: classInfo.classInfoName,
										data: membersInfoFromExcel,
								  }
								: classInfo
						)
					);
				});
			});

			// Statistical tab slide 3
			const studentListElm = $(
				".settings-box__wrapper .tab-list__item.statistical .statistical__slide-3 .slide-3__student-wrapper"
			);

			studentListElm.addEventListener("change", (e) => {
				const target = e.target;

				if (
					target.tagName === "SELECT" &&
					target.className.includes("not-exist-status__select")
				) {
					const studentIndex = +target.dataset.index;

					attendanceObj.attendanceData.some(
						(studentInfo, index, arrayOrigin) => {
							if (studentInfo.index === studentIndex) {
								console.log(studentInfo);
								arrayOrigin[index].acceptNotExist =
									target.value == 1
										? false
										: target.value == 2
										? true
										: studentInfo.acceptNotExist;

								return true;
							}
						}
					);
				}
			});
		},

		intervalHandle() {
			this.handleIntervalFunc = setInterval(function () {
				if (
					$(".settings-box__wrapper.show") &&
					$(`.list__item.active[data-index="2"]`)
				) {
					reRenderNotExistList();
				}

				function reRenderNotExistList() {
					const membersList = attendanceObj.attendanceData;
					const membersExistMeetName = [
						...$$(".KsCJ0 .kvLJWc .ZjFb7c"),
					].map((elm) => elm.textContent);
					const studentNotExistInfo = membersList.filter(
						(member) =>
							!membersExistMeetName.includes(member.meetName)
					);

					// Render students not exist list
					const notExistListContainer = $(".not-exist-student__box");
					const notExistListDisplayed = [
						...$$(".not-exist-student__box > *"),
					];

					while (
						notExistListDisplayed.length > studentNotExistInfo.length
					) {
						notExistListDisplayed.pop().remove();
					}

					studentNotExistInfo.forEach((studentInfo, index) => {
						const attendanceSettingsState =
							settingsObj.getSettings().autoAttendance;

						if (index > notExistListDisplayed.length - 1) {
							const boxItem = document.createElement("div");

							boxItem.className = "box__item";
							boxItem.innerHTML = `<span class="item__index"> <p>${
								studentInfo.index
							}</p></span><span class="item__name"> <p>${
								studentInfo.name
							}</p> </span> <span class="item__online-state"><p>${
								attendanceSettingsState
									? studentInfo.acceptNotExist
										? "C.P"
										: "K.P"
									: ""
							}</p></span>`;

							notExistListContainer.appendChild(boxItem);
						} else {
							const currentStudentIndexElm = ($(
								".item__index p",
								notExistListDisplayed[index]
							).textContent = studentInfo.index);

							const currentStudentNameElm = ($(
								".item__name p",
								notExistListDisplayed[index]
							).textContent = studentInfo.name);

							const currentStudentOnlineStateElm = ($(
								".item__online-state p",
								notExistListDisplayed[index]
							).textContent = attendanceSettingsState
								? studentInfo.acceptNotExist
									? "C.P"
									: "K.P"
								: "");
						}
					});
				}
			}, 1000);
		},

		settingsBoxFeaturesResetStyle() {
			const settings = settingsObj.getSettings();
			const autoTurnOffMediaInput = $(
				".settings-box__wrapper .tab-list__item.features .features__auto-turn-off-media .toggle-btn input"
			);
			const autoAcceptInput = $(
				".settings-box__wrapper .tab-list__item.features .features__auto-accept .toggle-btn input"
			);
			const blockAccessInvalidInput = $(
				".settings-box__wrapper .tab-list__item.features .features__authenticate .toggle-btn input"
			);
			const autoAttendanceInput = $(
				".settings-box__wrapper .tab-list__item.features .features__auto-attendance .toggle-btn input"
			);

			if (settings.autoTurnOffMedia)
				autoTurnOffMediaInput.checked = true;
			else autoTurnOffMediaInput.checked = false;

			if (settings.autoAccept) autoAcceptInput.checked = true;
			else autoAcceptInput.checked = false;

			if (settings.blockAccessInvalid)
				blockAccessInvalidInput.checked = true;
			else blockAccessInvalidInput.checked = false;

			if (settings.autoAttendance) autoAttendanceInput.checked = true;
			else autoAttendanceInput.checked = false;
		},

		resetStyleToolsbarBtnStudentList() {
			const selectedCountElm = $(
				".settings-box__wrapper .student-list__table .left-slide__selected-count"
			);
			const deleteBtn = $(
				".settings-box__wrapper .student-list__table .right-slide__delete"
			);
			const selectAllBtn = $(
				".settings-box__wrapper .student-list__table .left-slide__select-all"
			);
			const unSelectAllBtn = $(
				".settings-box__wrapper .student-list__table .left-slide__unselect-all"
			);
			const allInput = [
				...$$(".settings-box__wrapper .body__row .row__select input"),
			];
			const allInputChecked = [
				...$$(
					".settings-box__wrapper .body__row .row__select input:checked"
				),
			];

			// Select all button
			if (allInputChecked.length < allInput.length) {
				selectAllBtn.classList.remove("disabled");
			} else {
				selectAllBtn.classList.add("disabled");
			}

			// Unselect all button
			if (allInputChecked.length > 0) {
				unSelectAllBtn.classList.remove("disabled");
			} else {
				unSelectAllBtn.classList.add("disabled");
			}

			selectedCountElm.textContent = `đã chọn ${this.studentsSelectedIndex.length}`;

			// Delete student selected button
			if (allInput.length === 0 || allInputChecked.length === 0) {
				deleteBtn.classList.add("disabled");
			} else {
				deleteBtn.classList.remove("disabled");
			}
		},

		renderClassList() {
			const classListContainer = $(
				".settings-box__wrapper .tab-list__item.student-list .left-slide__class-list"
			);
			const allClassName = membersObj.getAllClassName();

			classListContainer.innerHTML = "";

			allClassName.forEach((classInfoName) => {
				if (classInfoName === "default") return;

				const classBtnElm = document.createElement("li");

				// Set style
				classBtnElm.className = `class-list__class ${
					membersObj.getCurrentClassInfoName() === classInfoName
						? "active"
						: ""
				}`;
				classBtnElm.innerHTML = `<div class="nav-ctn"><div class="nav-ctn__edit"><img src="${getLink(
					"img/editIcon.png"
				)}" alt="" /></div><div class="nav-ctn__close"><img src="${getLink(
					"img/closeIcon(2).png"
				)}" alt=""/></div></div><img src="${getLink(
					"img/listContactIcon.png"
				)}" alt="" /><p>${classInfoName}</p>`;

				// Set event
				classBtnElm.addEventListener("click", (e) => {
					if (settingsObj.getSettings().autoAttendance)
						return alert(
							"Vui lòng tắt điểm danh tự động trước khi đổi lớp học!"
						);

					if (classBtnElm.className.includes("active")) {
						membersObj.setCurrentClass("default");
					} else {
						membersObj.setCurrentClass(classInfoName);
					}

					this.studentsSelectedIndex = [];
					this.renderClassList();
					this.renderStudentList();
				});
				classListContainer.appendChild(classBtnElm);

				// Delete btn handle
				const deleteCurrentClassBtn = $(
					".nav-ctn__close",
					classBtnElm
				);

				deleteCurrentClassBtn.addEventListener(
					"click",
					handleDeleteCurrentClass
				);

				function handleDeleteCurrentClass(e) {
					e.stopPropagation();

					if (settingsObj.getSettings().autoAttendance)
						return alert(
							"Vui lòng tắt điểm danh tự động trước khi chỉnh sửa thông tin này!"
						);

					const newAllClassInfo = membersObj
						.getAllClassInfo()
						.filter(
							(classInfo) =>
								classInfo.classInfoName != classInfoName
						);

					classPageObj.undoAndRedoMembersList.addHistory(
						classInfoName,
						newAllClassInfo
					);
				}

				// Edit btn handle
				const editCurrentClassBtn = $(".nav-ctn__edit", classBtnElm);

				editCurrentClassBtn.addEventListener(
					"click",
					handleEditCurrentClass
				);

				function handleEditCurrentClass(e) {
					e.stopPropagation();

					if (settingsObj.getSettings().autoAttendance)
						return alert(
							"Vui lòng tắt điểm danh tự động trước khi chỉnh sửa thông tin này!"
						);

					const newClassInfoName = prompt(
						"Nhập tên mới của lớp này:",
						classInfoName
					);
					if (newClassInfoName === null) return;
					if (!newClassInfoName) return;

					const newAllClassInfo = membersObj
						.getAllClassInfo()
						.map((classInfo) =>
							classInfo.classInfoName === classInfoName
								? {
										...classInfo,
										classInfoName: newClassInfoName,
								  }
								: classInfo
						);

					classPageObj.undoAndRedoMembersList.addHistory(
						classInfoName,
						newAllClassInfo
					);
				}
			});
		},

		async renderStudentList() {
			const currentStudentList = membersObj.getClass().data;
			const studentListElm = $(
				".settings-box__wrapper .student-table__body"
			);
			const allMemberRows = [];

			studentListElm.innerHTML = "";

			currentStudentList
				.sort(
					(firstElm, secondElm) => firstElm.index - secondElm.index
				)
				.forEach((member) => {
					const memberRow = document.createElement("tr");

					memberRow.dataset.studentIndex = member.index;
					memberRow.className = "body__row";
					memberRow.innerHTML = `
					<td class="row__index">
							<input
								type="text"
								value="${member.index}"
								spellcheck="false"
							/>
							<div></div>
					</td>
					<td class="row__name">
							<input
								type="text"
								value="${member.name}"
								spellcheck="false"
							/>
							<div></div>
					</td>
					<td class="row__meet-name">
							<input type="text" value="${member.meetName}" spellcheck="false" />
							<div></div>
					</td>
					<td class="row__gmail">
							<input type="text" value="${
								member.gmail
							}" placeholder="Chưa nhập Gmail" spellcheck="false" />
							<div></div>
					</td>
					<td class="row__exist-state"><p>Chưa vào</p></td>
					<td class="row__select">
						<label class="select__icon">
							<input type="checkbox" ${
								this.studentsSelectedIndex.includes(member.index)
									? "checked"
									: ""
							}/>
							<img class="icon__checked" src="${getLink("img/checkIcon.png")}" alt="" />
						</label>
					</td>			  
			`;

					allMemberRows.push(memberRow);
					studentListElm.appendChild(memberRow);
				});

			// Update table student list per second
			function setIntervalHandle() {
				clearInterval(this.updateStudentListInterval);

				handleUpdate();

				this.updateStudentListInterval = setInterval(
					handleUpdate,
					1000
				);

				function handleUpdate() {
					const allStudentsNameExist = Array.from(
						$$(".KsCJ0 .kvLJWc .ZjFb7c")
					).map((elm) => elm.textContent);

					const existStatesArray = currentStudentList.map(
						(studentInfo) =>
							allStudentsNameExist.includes(studentInfo.meetName)
								? "Đang học"
								: "Chưa vào"
					);

					existStatesArray.forEach((stateMessage, index) => {
						const currentMemberRow = allMemberRows[index];
						const stateContentElm = $(
							".row__exist-state",
							currentMemberRow
						);

						stateContentElm.textContent = stateMessage;

						if (stateMessage === "Đang học") {
							currentMemberRow.classList.remove("not-exist");
						} else {
							currentMemberRow.classList.add("not-exist");
						}
					});
				}
			}
			setIntervalHandle.call(this);
		},

		renderAttendanceHistoryList() {
			const attendanceHistoryWrapperElm = $(
				".settings-box__wrapper .tab-list__item.attendance-history .attendance-history__wrapper"
			);
			const attendanceHistoryListData = attendanceHistoryObj
				.getHistory()
				.reverse();
			const imagesLink = [
				getLink("img/teacher-0.png"),
				getLink("img/teacher-1.png"),
				getLink("img/teacher-2.png"),
				getLink("img/teacher-3.png"),
				getLink("img/teacher-4.png"),
			];

			attendanceHistoryWrapperElm.innerHTML = "";

			attendanceHistoryListData.forEach((historyItem, index) => {
				const newHistoryItem = document.createElement("li");
				const timeLearningConverted = generalMethods.convertTimeSecond(
					historyItem.totalTimeLearning
				);
				const startAttendanceTime = historyItem.startAttendanceAt;
				const endAttendanceTime = historyItem.endAttendanceAt;
				const imageLink =
					imagesLink[Math.floor(Math.random() * (4 - 0 + 1) + 0)];

				const startLearningTimeStr =
					startAttendanceTime.dates === endAttendanceTime.dates
						? generalMethods.getTimeStr(
								true,
								false,
								false,
								startAttendanceTime
						  )
						: generalMethods.getTimeStr(
								true,
								true,
								true,
								startAttendanceTime
						  );
				const endLearningTimeStr = generalMethods.getTimeStr(
					true,
					true,
					true,
					endAttendanceTime
				);

				newHistoryItem.dataset.index =
					attendanceHistoryListData.length - index - 1; //Because attendanceHistoryListData is reversed
				newHistoryItem.className = "wrapper__item";
				newHistoryItem.innerHTML = `<img src="${imageLink}" alt=""/><div class="item__right-slide"> <div class="right-slide__class-name-info"> <span>Lớp học:</span> <p>${
					historyItem.classInfoName
				}</p> </div> <div class="right-slide__time"> <span>Học từ:</span> <p>${startLearningTimeStr} - ${endLearningTimeStr}</p> </div> <div class="right-slide__time-learning"> <span>Thời gian:</span> <p>${
					timeLearningConverted.hours
				}:${timeLearningConverted.minutes}:${
					timeLearningConverted.seconds
				}</p> </div> <div class="right-slide__btn-ctn"> <button class="right-slide__to-excel-btn"> <img src="${getLink(
					"img/excelIcon.png"
				)}" alt=""/> </button> <button class="right-slide__to-pdf-btn"> <img src="${getLink(
					"img/pdfIcon.png"
				)}" alt=""/> </button> <button class="right-slide__delete-btn"> <img src="${getLink(
					"img/attendanceHistoryCloseItem.png"
				)}" alt=""/> </button> </div></div>`;

				attendanceHistoryWrapperElm.appendChild(newHistoryItem);
			});
		},

		settingsBoxPressEventHandle(e) {
			switch (e.keyCode) {
				case 27:
					classPageObj.settingsBox.close();
					break;
			}
		},

		open() {
			const settingsBoxWrapperElm = $(".settings-box__wrapper");
			settingsBoxWrapperElm.classList.add("show");

			document.addEventListener(
				"keydown",
				classPageObj.settingsBox.settingsBoxPressEventHandle
			);
		},

		close() {
			const settingsBoxWrapperElm = $(".settings-box__wrapper");
			settingsBoxWrapperElm.classList.remove("show");

			document.removeEventListener(
				"keydown",
				classPageObj.settingsBox.settingsBoxPressEventHandle
			);
		},

		addStudentBox: {
			existState: false,

			getAddStudentBoxElm: () =>
				$(
					".settings-box__wrapper .tab-list__item.student-list .student-list__add-student"
				),

			initial() {
				const addStudentBox = this.getAddStudentBoxElm();
				const indexInput = $(".index-ctn__input", addStudentBox);
				const nameInput = $(".name-ctn__input", addStudentBox);
				const meetNameInput = $(
					".meet-name-ctn__input",
					addStudentBox
				);
				const gmailInput = $(".gmail-ctn__input", addStudentBox);
				const submitBtn = $(".submit__submit-btn", addStudentBox);
				const errorMessageList = ["", "", ""];

				indexInput.addEventListener("focusout", handleCheckIndexValue);
				nameInput.addEventListener("focusout", handleCheckNameValue);
				meetNameInput.addEventListener(
					"focusout",
					handleCheckMeetNameValue
				);

				submitBtn.addEventListener("click", (e) => {
					if (settingsObj.getSettings().autoAttendance)
						return alert(
							"Vui lòng tắt điểm danh tự động trước khi sửa thông tin học sinh!"
						);

					const indexCheckResult = handleCheckIndexValue();
					const nameCheckResult = handleCheckNameValue();
					const meetNameCheckResult = handleCheckMeetNameValue();

					if (
						indexCheckResult &&
						nameCheckResult &&
						meetNameCheckResult
					) {
						const newClassInfo = membersObj.getClass();
						let allClassInfo = membersObj.getAllClassInfo();

						newClassInfo.data.push({
							index: Number(indexInput.value),
							name: nameInput.value,
							meetName: meetNameInput.value,
							gmail: generalMethods.validateEmail(gmailInput.value)
								? gmailInput.value
								: "Chưa nhập",
						});
						classPageObj.undoAndRedoMembersList.addHistory(
							membersObj.getCurrentClassInfoName(),
							allClassInfo.map((classInfo) =>
								classInfo.classInfoName ===
								membersObj.getCurrentClassInfoName()
									? newClassInfo
									: classInfo
							)
						);

						indexInput.value = "";
						nameInput.value = "";
						meetNameInput.value = "";
						gmailInput.value = "";
						indexInput.focus();
					}
				});

				function handleCheckIndexValue(e) {
					const membersIndex = membersObj
						.getClass(membersObj.getCurrentClassInfoName())
						.data.map((member) => member.index);
					const indexValue = indexInput.value;
					const illegalSymbolArr = [
						"0",
						"1",
						"2",
						"3",
						"4",
						"5",
						"6",
						"7",
						"8",
						"9",
					];
					const hasInvalidSymbol = indexValue
						.split("")
						.some((symbol) => !illegalSymbolArr.includes(symbol));

					indexInput.classList.add("fail");

					if (!indexValue) {
						errorMessageList[0] = "Chưa nhập Số thứ tự";
						renderErrorList();
						return false;
					}
					if (hasInvalidSymbol) {
						errorMessageList[0] =
							'Trường "STT" chỉ được phép chứa số!';
						renderErrorList();
						return false;
					}
					if (membersIndex.includes(Number(indexValue))) {
						errorMessageList[0] = "STT này đã có người sử dụng!";
						renderErrorList();
						return false;
					}

					indexInput.classList.remove("fail");
					errorMessageList[0] = "";
					renderErrorList();
					return true;
				}

				function handleCheckNameValue(e) {
					const nameValue = nameInput.value;

					if (!nameValue) {
						nameInput.classList.add("fail");
						errorMessageList[1] = "Chưa nhập Họ và tên";
						renderErrorList();
						return false;
					}

					nameInput.classList.remove("fail");
					errorMessageList[1] = "";
					renderErrorList();
					return true;
				}

				function handleCheckMeetNameValue(e) {
					const meetNameValue = meetNameInput.value;

					if (!meetNameValue) {
						meetNameInput.classList.add("fail");
						errorMessageList[2] = "Chưa nhập Tên meet";
						renderErrorList();
						return false;
					}

					meetNameInput.classList.remove("fail");
					errorMessageList[2] = "";
					renderErrorList();
					return true;
				}

				function renderErrorList() {
					const messageBoxElm = $(
						".input__message-box",
						addStudentBox
					);
					const messageBoxContentElm = $("p", messageBoxElm);
					const errorListIsEmpty = errorMessageList.every(
						(errMessage) => !errMessage.length
					);

					if (errorListIsEmpty) {
						messageBoxContentElm.textContent = "";
						messageBoxElm.classList.remove("show");
					} else {
						const messageHtmls = errorMessageList
							.map((errMessage) =>
								errMessage ? `${errMessage} || ` : ""
							)
							.join("")
							.slice(0, -3);

						messageBoxContentElm.innerHTML = messageHtmls;
						messageBoxElm.classList.add("show");
					}
				}
			},

			open() {
				const studentBox = this.getAddStudentBoxElm();
				studentBox.style.display = "flex";
				studentBox.style.animation =
					"showAddStudentBox ease 300ms forwards";
				this.existState = true;
			},

			async close() {
				const studentBox = this.getAddStudentBoxElm();

				studentBox.style.animation =
					"hideAddStudentBox ease 300ms forwards";
				await generalMethods.sleep(300);
				studentBox.style.display = "none";
				this.existState = false;
			},
		},
	};

	autoAcceptHandler = {
		turnOn() {
			this.interval = setInterval(this.handleAccept.bind(this), 1000);
		},

		turnOff() {
			const settings = settingsObj.getSettings();
			const newSettings = {
				...settings,
				autoAccept: false,
			};

			settingsObj.setSettings(newSettings);
		},

		handleAccept() {
			const admitBox = $("div.g3VIld.iUQSvf.vDc8Ic.J9Nfi.iWO5td");
			const settings = settingsObj.getSettings();

			// Check has enabled
			if (!settings.autoAccept) return clearInterval(this.interval);
			if (!admitBox) return;

			// Direction to single or multiple accept
			if (settings.blockAccessInvalid) {
				this.blockAccessInvalid();
			} else {
				this.noBlockAccessInvalid();
			}
		},

		noBlockAccessInvalid() {
			const acceptAdmitBtn = [...$$(".CwaK9 .RveJvd.snByac")].pop();
			if (acceptAdmitBtn) acceptAdmitBtn.click();
		},

		blockAccessInvalid() {
			const singleTitle = $(".AmEdyd");
			const meetNames = membersObj
				.getClass(membersObj.getCurrentClassInfoName())
				.data.map((elm) => elm.meetName);

			if (singleTitle) {
				// single accept handle
				const admitUsername = $(".sKJ7pc .W0LGoe").textContent;
				const allBtn = [...$$(".QVfAkb .RveJvd.snByac")];
				const acceptBtn = allBtn.pop();
				const denyBtn = allBtn.pop();

				if (meetNames.includes(admitUsername)) {
					console.log("single accept", admitUsername);
					acceptBtn.click();
				} else {
					console.log("single deny", admitUsername);
					denyBtn.click();
				}
			} else {
				//  ---- multiple accept handle ----
				// Show all admit
				(async function showAllAdmit() {
					const firstAdmit = $(".z1tufc.eIHGxf");

					if (!firstAdmit) {
						const showAllAdmitBtn = [
							...$$(".CwaK9 .RveJvd.snByac"),
						].at(-1);
						showAllAdmitBtn.click();
						await generalMethods.sleep(50);
						showAllAdmit();
					}
				})();

				// Handle accept
				(async function handleAccept() {
					let isTimeout = false;

					// Timeout is true when over 800ms
					setTimeout(() => {
						isTimeout = true;
					}, 800);

					const interval = setInterval(async () => {
						const firstAdmit = $(".z1tufc.eIHGxf");
						if (!firstAdmit || isTimeout)
							return clearInterval(interval);

						const allBtn = [
							...$$(".NPEfkd.RveJvd.snByac", firstAdmit),
						];
						const admitUsername = $(
							".vczLke",
							firstAdmit
						).textContent;
						const acceptAdmitBtn = allBtn.pop();
						const denyAdmitBtn = allBtn.pop();

						if (meetNames.includes(admitUsername)) {
							console.log("multiple accept", admitUsername);
							acceptAdmitBtn.click();
						} else {
							console.log("multiple deny", admitUsername);
							denyAdmitBtn.click();
						}
					}, 300);
				})();
			}
		},
	};

	undoAndRedoMembersList = {
		history: [
			{
				currentClass: membersObj.getCurrentClassInfoName(),
				allClassInfo: membersObj.getAllClassInfo(),
			},
		],
		historyMaxLength: 30,
		currentPointerIndex: 0,

		initial() {
			this.resetStyleBtns();
		},

		addHistory(currentClass, allClassInfo) {
			if (this.currentPointerIndex < this.history.length - 1)
				this.history.splice(
					this.currentPointerIndex + 1,
					this.history.length - (this.currentPointerIndex + 1)
				);
			if (this.history.length === this.historyMaxLength) {
				this.history.shift();
				this.currentPointerIndex--;
			}

			this.history.push({
				currentClass,
				allClassInfo,
			});
			this.currentPointerIndex++;
			this.renderView();
			this.resetStyleBtns();
		},

		undo() {
			if (this.currentPointerIndex === 0) return;
			this.currentPointerIndex--;
			this.renderView();
			this.resetStyleBtns();
		},

		redo() {
			if (this.currentPointerIndex === this.history.length - 1) return;
			this.currentPointerIndex++;
			this.renderView();
			this.resetStyleBtns();
		},

		renderView() {
			const currentHistory = this.history[this.currentPointerIndex];

			membersObj.setCurrentClass(currentHistory.currentClass);
			membersObj.setAllClass(currentHistory.allClassInfo, true);

			classPageObj.settingsBox.renderClassList();
			classPageObj.settingsBox.resetStyleToolsbarBtnStudentList();
		},

		resetStyleBtns() {
			const undoBtn = $(
				".settings-box__wrapper .box__body .tab-list__item.student-list .right-slide__undo"
			);
			const redoBtn = $(
				".settings-box__wrapper .box__body .tab-list__item.student-list .right-slide__redo"
			);

			if (this.currentPointerIndex === null) {
				undoBtn.classList.add("disabled");
				redoBtn.classList.add("disabled");
				return;
			}

			if (this.currentPointerIndex === 0) {
				undoBtn.classList.add("disabled");
			} else {
				undoBtn.classList.remove("disabled");
			}

			if (this.currentPointerIndex === this.history.length - 1) {
				redoBtn.classList.add("disabled");
			} else {
				redoBtn.classList.remove("disabled");
			}
		},
	};
}
var classPageObj = new ClassPage();

window.addEventListener("load", mainObj.run);
